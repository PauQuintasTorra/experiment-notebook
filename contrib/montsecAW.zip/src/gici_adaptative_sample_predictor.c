#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "utils/header.h"
#include "utils/body.h"
#include "utils/image_converter.h"

#define BUFFER_SIZE 1024

double PWeights[18] = { 1.0 / 21, 1.0 / 21, 1.0 / 21, 1.0 / 21, 0.0 / 21,
                        1.0 / 21, 1.0 / 21, 1.0 / 21, 1.0 / 21, 0.0 / 21, 
                        1.0 / 21, 1.0 / 21, 1.0 / 21, 2.0 / 21, 2.0 / 21, 
                        1.0 / 21, 2.0 / 21, 3.0 / 21
                       };

double accumulated_update[18] = {0};
uint64_t accumulator = 0;

uint16_t map_difference(int residual, int prediction, int min, int max) {
    int32_t theta = (prediction - min < max - prediction) ? (prediction - min) : (max - prediction);
    uint16_t mappedDiff = 0;
    if (residual >= 0 && residual <= theta) {
        mappedDiff = residual << 1;
    } else if (residual >= -theta && residual < 0) {
        mappedDiff = (abs(residual) << 1) - 1;

    } else {
        mappedDiff = theta + abs(residual);
    }

    return mappedDiff;
}

int unmap_difference(uint16_t mapped_difference, int prediction, int min, int max) {
    uint32_t left_interval = (prediction - min <= max - prediction);
    int32_t theta = left_interval ? (prediction - min) : (max - prediction);
    int prediction_error;

    if (mapped_difference <= (theta << 1)) {
        if ((mapped_difference & 1) == 0) {
            prediction_error = mapped_difference >> 1;
        } else {
            prediction_error = -((mapped_difference + 1) >> 1);
        }
    } else {
        if (left_interval) {
            prediction_error = mapped_difference - theta;
        } else {
            prediction_error = theta - mapped_difference;
        }
    }

    return prediction_error;
}

double sign(double x) {
    return (x > 0) - (x < 0);
}

void update_weights(uint64_t ***inputData, double prediction, int z, int y, int x, double lr, double L1, double L2, double alpha, double gamma, double batch) {
    double update_weight = (inputData[z][y][x] - prediction) * lr;
    accumulator++;

    for (int i = 0; i < 18; i++) {
        if (i != 4 && i != 9) {
            // Update with Kallman
            accumulated_update[i] += alpha * PWeights[i] + (1 - alpha) * update_weight * inputData[z][y - 3 + (i / 5)][x - 3 + (i % 5)];
            
            // L1 regularization
            accumulated_update[i] -= L1 * sign(PWeights[i]);

            // L2 regularization
            accumulated_update[i] -= L2 * PWeights[i]; 
            
            // Forgetting Factor
            accumulated_update[i] *= (1 - gamma);
        }
    }

    // Batch update
    if (accumulator == batch) {
        for (int i = 0; i < 18; i++) {
            if (i != 4 && i != 9) {
                PWeights[i] += accumulated_update[i] / batch;
                accumulated_update[i] = 0;
            }
        }
        accumulator = 0;
    } 

}

int predict(uint64_t ***inputData, double *n_pred, int min, int max, int depth, int rows, int columns, int z, int y, int x) {
    int prediction = 0;

    if (x >= 3 && y >= 3 && x < columns - 1) {
        double n_prediction = 0;
        for (int i = 0; i < 18; i++) {
            n_prediction += inputData[z][y - 3 + (i / 5)][x - 3 + (i % 5)] * PWeights[i];
        }
                      
        *n_pred = n_prediction;

        if (n_prediction > max) {
            prediction = max;
        }
        else if (n_prediction < min) {
            prediction = min;
        }
        else {
            prediction = (int)round(n_prediction);
        }

        return prediction;
    }

    if (x >= 3 && y >= 2 && x < columns - 1) {
        prediction = ((inputData[z][y-1][x] << 1) + inputData[z][y][x-1] * 3 +
                      (inputData[z][y][x-2] << 1) + inputData[z][y][x-3] +
                      inputData[z][y-1][x-1] + inputData[z][y-1][x-2] +
                      inputData[z][y-1][x-3] + inputData[z][y-1][x+1] +
                      inputData[z][y-2][x] + inputData[z][y-2][x-1] +
                      inputData[z][y-2][x-2] + inputData[z][y-2][x-3] +
                      inputData[z][y-1][x+1]) / 17;
        return prediction;
    }

    if (x >= 2 && y >= 2 && x < columns - 1) {
        prediction = ((inputData[z][y-1][x] << 1) + inputData[z][y][x-1] * 3 +
                      inputData[z][y][x-2] + inputData[z][y-1][x-1] +
                      inputData[z][y-1][x-2] + inputData[z][y-1][x+1] +
                      inputData[z][y-2][x] + inputData[z][y-2][x-1] +
                      inputData[z][y-2][x-2] + inputData[z][y-1][x+1]) / 13;
        return prediction;
    }

    if (x >= 2 && y >= 1 && x < columns - 1) {
        prediction = ((inputData[z][y-1][x] << 1) + inputData[z][y][x-1] * 3 +
                      inputData[z][y][x-2] + inputData[z][y-1][x-1] +
                      inputData[z][y-1][x-2] + inputData[z][y-1][x+1]) / 9;
        return prediction;
    }

    if (x >= 1 && y >= 1 && x < columns - 1) {
        prediction = ((inputData[z][y-1][x] << 1) + inputData[z][y][x-1] * 3 +
                      inputData[z][y-1][x-1] + inputData[z][y-1][x+1]) / 7;
        return prediction;
    }

    if (x >= 2 && y >= 1) {
        prediction = ((inputData[z][y-1][x] << 1) + inputData[z][y][x-1] * 3 +
                      (inputData[z][y][x-2] << 1) + inputData[z][y-1][x-1]) / 8;
        return prediction;
    }

    if (x >= 1 && y >= 1) {
        prediction = ((inputData[z][y-1][x] << 1) + inputData[z][y][x-1] * 3 +
                      inputData[z][y-1][x-1]) / 6;
        return prediction;
    }

    if (x == 0 && y >= 1) {
        prediction = inputData[z][y-1][x];
        return prediction;
    }

    if (y == 0 && x >= 2) {
        prediction = (inputData[z][y][x-1] + inputData[z][y][x-2]) >> 1;
        return prediction;
    }

    if (y == 0 && x >= 1) {
        prediction = inputData[z][y][x-1];
        return prediction;
    }

    if (x == 0 && y == 0) {
        prediction = 0;
        return prediction;
    }

    return prediction;
}



int main(int argc, char *argv[]) {
    if (argc != 7) {
        fprintf(stderr, "Usage: %s\n <LR> <L1> <L2> <alpha> <gamma> <batch>", argv[0]);
        return 1;
    }

     double lr = atof(argv[1]);

     double L1 = atof(argv[2]);

     double L2 = atof(argv[3]);

     double alpha = atof(argv[4]);

     double gamma = atof(argv[5]);

     uint64_t batch = atoi(argv[6]);


    Header header;
    if (header_parse_stdin(&header) != 0) {
        return 1;
    }

    DataPacket imageData = {0}; 

    while(body_parse_stdin(&imageData) == 0) {
        if ((imageData.type != DATA_TYPE_IMAGE) && (imageData.type != DATA_TYPE_RESIDUALS)) {
            continue; // Implement a forward data
        }

        uint64_t ***inputData = NULL;

        if (get_image_from_stdin(&imageData, header, &inputData) != 0) {
            fprintf(stderr, "Error generating image\n");
            return 1;
        }

        if (header.state == COMPRESS) {
            header.data = RESIDUAL;
        }
        else {
            header.data = RAW;
        }

        print_header(&header);


        DataPacket outputData = {0}; 
        outputData.id = 0;
        outputData.bits = header.bits;
        outputData.endian = 'l';

        if (header.state == COMPRESS) {
            outputData.type = DATA_TYPE_RESIDUALS;

            start_body(&outputData, stdout);

            void* row_buffer;
            size_t pixel_size = (header.bits == 8) ? sizeof(uint8_t) : sizeof(uint16_t);
            size_t buffer_size = header.x * header.y * header.z * pixel_size;
            row_buffer = malloc(buffer_size);

            size_t min = 0;
            size_t max = (1 << header.bits) - 1;
            
            double n_pred;

            for (size_t z = 0; z < header.z; z++) {
                for (size_t y = 0; y < header.y; y++) {
                    for (size_t x = 0; x < header.x; x++) {
                        uint16_t prediction = predict(inputData, &n_pred, min, max, header.z, header.y, header.x, z, y, x);                                       
                        uint16_t mapped_residual = map_difference((int32_t)(inputData[z][y][x] - prediction), prediction, min, max);
                        
                        if (y >= 3 && x >= 3 && x < header.x - 1) {
                            update_weights(inputData, n_pred, z, y, x, lr, L1, L2, alpha, gamma, batch);
                        }

                        if (header.bits == 8) {
                            ((uint8_t*)row_buffer)[(z * header.y + y) * header.x + x] = (uint8_t)mapped_residual;
                        } else {
                            ((uint16_t*)row_buffer)[(z * header.y + y) * header.x + x] = mapped_residual;
                        }
                    }
                }
            }
            
            fwrite(row_buffer, pixel_size, header.x * header.y * header.z, stdout);
            free(row_buffer);
            end_body(&outputData, stdout);
        }
        else {
            outputData.type = DATA_TYPE_IMAGE;

            start_body(&outputData, stdout);

            void* row_buffer;
            size_t pixel_size = (header.bits == 8) ? sizeof(uint8_t) : sizeof(uint16_t);
            size_t buffer_size = header.x * header.y * header.z * pixel_size;
            row_buffer = malloc(buffer_size);

            size_t min = 0;
            size_t max = (1 << header.bits) - 1;
            
            double n_pred;

            for (size_t z = 0; z < header.z; z++) {
                for (size_t y = 0; y < header.y; y++) {
                    for (size_t x = 0; x < header.x; x++) {
                        uint16_t prediction = predict(inputData, &n_pred, min, max, header.z, header.y, header.x, z, y, x);
                        uint16_t result = unmap_difference(inputData[z][y][x], prediction, min, max) + prediction;
                        inputData[z][y][x] = result;
                        
                        if (y >= 3 && x >= 3 && x < header.x - 1) {
                            update_weights(inputData, n_pred, z, y, x, lr, L1, L2, alpha, gamma, batch);
                        }
                        
                        if (header.bits == 8) {
                            ((uint8_t*)row_buffer)[(z * header.y + y) * header.x + x] = (uint8_t)result;
                        } else {
                            ((uint16_t*)row_buffer)[(z * header.y + y) * header.x + x] = result;
                        }
                    }
                }
            }

            fwrite(row_buffer, pixel_size, header.x * header.y * header.z, stdout);
            free(row_buffer);
            end_body(&outputData, stdout);
        }

        free_image(inputData, header);

    }

    return 0;
}

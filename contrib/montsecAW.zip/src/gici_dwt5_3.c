#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "utils/header.h"
#include "utils/body.h"
#include "utils/image_converter.h"

static inline uint64_t zigzag_encode(int64_t value) {
    return (uint64_t)((value << 1) ^ (value >> 63));
}

static inline int64_t zigzag_decode(uint64_t value) {
    return (int64_t)((value >> 1) ^ -(value & 1));
}

void lifting_5_3(uint64_t *signal, int64_t *residuals, int length) {
    int i;

    for (i = 0; i < length; i++) {
        residuals[i] = signal[i];
    }
    
    for (i = 1; i < length - 1; i += 2) {
        residuals[i] -= (residuals[i - 1] + residuals[i + 1]) / 2;
    }

    for (i = 0; i < length; i += 2) {
        if (i - 1 >= 0 && i + 1 < length) {
            residuals[i] += (residuals[i - 1] + residuals[i + 1] + 2) / 4;
        }
    }
}

void inverse_lifting_5_3(int64_t *residuals, int64_t *signal, int length) {
    int i;

    for (i = 0; i < length; i++) {
        signal[i] = residuals[i];
    }

    for (i = 0; i < length; i += 2) {
        if (i - 1 >= 0 && i + 1 < length) {
            signal[i] -= (signal[i - 1] + signal[i + 1] + 2) / 4;
        }
    }

    for (i = 1; i < length - 1; i += 2) {
        signal[i] += (signal[i - 1] + signal[i + 1]) / 2;
    }
}

int64_t ***wavelet_5_3_transform(uint64_t ***image, int width, int height) {
    int x, y;
    int64_t *temp_col = (int64_t *)malloc(height * sizeof(int64_t));
    int64_t ***residuals;

    initialize_residual_matrix(1, height, width, &residuals);

    for (y = 0; y < height; y++) {
        lifting_5_3((int64_t*)image[0][y], residuals[0][y], width);
    }

    for (x = 0; x < width; x++) {
        for (y = 0; y < height; y++) {
            temp_col[y] = residuals[0][y][x];
        }

        lifting_5_3(temp_col, temp_col, height);

        for (y = 0; y < height; y++) {
            residuals[0][y][x] = temp_col[y];
        }
    }

    free(temp_col);

    return residuals;
}

uint64_t ***inverse_wavelet_5_3_transform(int64_t ***residual, int width, int height) {
    int x, y;
    int64_t *temp_col = (int64_t *)malloc(height * sizeof(int64_t));
    uint64_t ***image;
    initialize_image_matrix(1, height, width, &image);

    for (x = 0; x < width; x++) {
        for (y = 0; y < height; y++) {
            temp_col[y] = residual[0][y][x];
        }

        inverse_lifting_5_3(temp_col, temp_col, height);

        for (y = 0; y < height; y++) {
            image[0][y][x] = temp_col[y];
        }
    }

    for (y = 0; y < height; y++) {
        inverse_lifting_5_3(residual[0][y], (int64_t *)image[0][y], width);
    }

    free(temp_col);

    return image;
}

int main(int argc, char *argv[]) {
    if (argc != 1) {
        fprintf(stderr, "Usage: %s\n", argv[0]);
        return 1;
    }

    Header header;
    if (header_parse_stdin(&header) != 0) {
        return 1;
    }

    DataPacket imageData = {0}; 

    while(body_parse_stdin(&imageData) == 0) {
        if ((imageData.type != DATA_TYPE_IMAGE) && (imageData.type != DATA_TYPE_RESIDUALS)) {
            continue; // Implement a forward data
        }

        uint64_t ***inputData = NULL;

        if (get_image_from_stdin(&imageData, header, &inputData) != 0) {
            fprintf(stderr, "Error generating image\n");
            return 1;
        }

        if (header.state == COMPRESS) {
            header.data = RESIDUAL;
        }
        else {
            header.data = RAW;
        }

        print_header(&header);


        DataPacket outputData = {0}; 
        outputData.id = 0;
        outputData.bits = header.bits;
        outputData.endian = 'l';

        if (header.state == COMPRESS) {
            outputData.type = DATA_TYPE_RESIDUALS;

            start_body(&outputData, stdout);
            int64_t ***residuals = wavelet_5_3_transform(inputData, header.x, header.y);
            
            for (size_t z = 0; z < header.z; z++) {
                for (size_t y = 0; y < header.y; y++) {
                    for (size_t x = 0; x < header.x; x++) {
                        fprintf(stderr, "%zu %zu %zu --> %llu %lld\n", z, y, x, inputData[z][y][x], residuals[z][y][x]);
                        fwrite(residuals[z][y][x], (header.bits == 8) ? sizeof(uint8_t) : sizeof(uint16_t), header.x, stdout);
                    }

                }
            }

            size_t min = 0;
            size_t max = (1 << header.bits) - 1;

            end_body(&outputData, stdout);
        }
        else {
            outputData.type = DATA_TYPE_IMAGE;

            start_body(&outputData, stdout);


            uint64_t ***inputData = NULL;

            if (get_image_from_stdin(&imageData, header, &inputData) != 0) {
                fprintf(stderr, "Error generating image\n");
                return 1;
            }

            for (size_t z = 0; z < header.z; z++) {
                for (size_t y = 0; y < header.y; y++) {
                    for (size_t x = 0; x < header.x; x++) {
                        fprintf(stderr, "%zu %zu %zu --> %lld\n", z, y, x, (int64_t)inputData[z][y][x]);
                    }
                }
            }


            size_t min = 0;
            size_t max = (1 << header.bits) - 1;

            uint64_t ***image = inverse_wavelet_5_3_transform((int64_t ***)inputData, header.x, header.y);

            for (size_t z = 0; z < header.z; z++) {
                for (size_t y = 0; y < header.y; y++) {
                    for (size_t x = 0; x < header.x; x++) {
                        fprintf(stderr, "%zu %zu %zu --> %llu %lld\n", z, y, x, image[z][y][x], (int64_t)inputData[z][y][x]);
                        fwrite(image[z][y][x], (header.bits == 8) ? sizeof(uint8_t) : sizeof(uint16_t), header.x, stdout);
                    }

                }
            }

            end_body(&outputData, stdout);
        }

        free_image(inputData, header);

    }

    return 0;
}

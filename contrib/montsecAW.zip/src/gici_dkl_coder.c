#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>


#include "utils/header.h"
#include "utils/body.h"
#include "utils/image_converter.h"

#define MAX_SYMBOLS 256
#define PRECISION 24

#define TOP_VALUE      ((1 << PRECISION) - 1)
#define HALF           (1 << (PRECISION - 1))


// Entropy vs probabilities
double PWeights[6] = { 1.0 / 6, 1.0 / 6, 1.0 / 6, 1.0 / 6, 1.0 / 6, 1.0 / 6};

double PWeights2[18] = { 1.0 / 21, 1.0 / 21, 1.0 / 21, 1.0 / 21, 0.0 / 21,
                         1.0 / 21, 1.0 / 21, 1.0 / 21, 1.0 / 21, 0.0 / 21, 
                         1.0 / 21, 1.0 / 21, 1.0 / 21, 2.0 / 21, 2.0 / 21, 
                         1.0 / 21, 2.0 / 21, 3.0 / 21
                      };


double PWeights3[23] = { 1.0 / 25, 1.0 / 25, 1.0 / 25, 1.0 / 25, 0.0 / 25,
                         1.0 / 25, 1.0 / 25, 1.0 / 25, 1.0 / 25, 0.0 / 25,
                         1.0 / 25, 1.0 / 25, 1.0 / 25, 1.0 / 25, 0.0 / 25, 
                         1.0 / 25, 1.0 / 25, 1.0 / 25, 2.0 / 25, 2.0 / 25, 
                         1.0 / 25, 2.0 / 25, 3.0 / 25
                      };

double PMemory = 0;

typedef enum {
    NO_CONTEXT,
    CONTEXT_LEFT,
    CONTEXT_UP,
    CONTEXT_UP_LEFT,
    CONTEXT_UP_LEFT_DIAGONAL,
    CONTEXT_UP_LEFT_MIXED,
    CONTEXT_UP_LEFT_SORTED,
    CONTEXT_UP_LEFT_DIAGONAL_MIXED,
    CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED,
    CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_WEIGHTED_MIXED,
    CONTEXT_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED,
    CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED,
    CONTEXT_ALL_TWO,
    CONTEXT_UP_LEFT_POWER,
    CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED_POWER,
    CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_REGRESSION,
    CONTEXT_ALL_REGRESSION,
    CONTEXT_PREDICTOR,
    CONTEXT_ALL_REGRESSION_MORE,
    CONTEXT_MAX,
    CONTEXT_EXTREME_MIXED
} ContextType;

typedef struct {
    // User information
    uint32_t n_symbols;
    ContextType context;
    uint32_t context_window;
    uint32_t update_periode;
    uint32_t softening;
    uint32_t ponderation;

    // Global data
    uint32_t low, high;
    uint64_t scale3;
    uint32_t ****simple_freq;
    uint32_t ****freq;
    uint32_t ****freq_window;

    // Encoder buffers
    uint8_t bit_buffer;
    uint64_t bit_count;
    
    // Decoder state
    uint32_t word_buffer;
    uint8_t input_byte;
    uint64_t bits_count;
} ArithmeticCoder;

/**
 * Global funcitons
 */


 int initialize_freq(uint64_t max_c1, uint64_t max_c2, uint64_t max_c3, uint16_t n_symbols, uint32_t *****freq) {
    *freq = (uint32_t ****)malloc(max_c1 * sizeof(uint32_t ***));

    if (!*freq) return 1;

    for (int i = 0; i < max_c1; i++) {
        (*freq)[i] = (uint32_t ***)malloc(max_c2 * sizeof(uint32_t **));
        if (!(*freq)[i]) {
            for (int j = 0; j < i; j++) {
                free((*freq)[j]);
            }
            free(*freq);
            return 1;
        }

        for (int j = 0; j < max_c2; j++) {
            (*freq)[i][j] = (uint32_t **)malloc(max_c3 * sizeof(uint32_t *));
            if (!(*freq)[i][j]) {
                for (int k = 0; k < j; k++) {
                    free((*freq)[i][k]);
                }
                free((*freq)[i]);
                for (int k = 0; k < i; k++) {
                    free((*freq)[k]);
                }
                free(*freq);
                return 1;
            }

            for (int k = 0; k < max_c3; k++) {
                (*freq)[i][j][k] = (uint32_t *)malloc((n_symbols + 1) * sizeof(uint32_t));
                if (!(*freq)[i][j][k]) {
                    for (int l = 0; l < k; l++) {
                        free((*freq)[i][j][l]);
                    }
                    free((*freq)[i][j]);
                    for (int l = 0; l < j; l++) {
                        for (int m = 0; m < max_c3; m++) {
                            free((*freq)[i][l][m]);
                        }
                        free((*freq)[i][l]);
                    }
                    free((*freq)[i]);
                    for (int l = 0; l < i; l++) {
                        for (int m = 0; m < max_c2; m++) {
                            for (int n = 0; n < max_c3; n++) {
                                free((*freq)[l][m][n]);
                            }
                            free((*freq)[l][m]);
                        }
                        free((*freq)[l]);
                    }
                    free(*freq);
                    return 1;
                }
            }
        }
    }
    return 0;
}

void free_freq(uint64_t max_c1, uint64_t max_c2, uint64_t max_c3, uint32_t *****freq) {
    if (!freq || !*freq) return;

    for (int i = 0; i < max_c1; i++) {
        if (!(*freq)[i]) continue;

        for (int j = 0; j < max_c2; j++) {
            if (!(*freq)[i][j]) continue;

            for (int k = 0; k < max_c3; k++) {
                free((*freq)[i][j][k]);
            }
            free((*freq)[i][j]);
        }
        free((*freq)[i]);
    }
    free(*freq);
    *freq = NULL;
}

void update_freq(ArithmeticCoder *coder, uint8_t symbol, uint64_t c1, uint64_t c2, uint64_t c3) {
    coder->simple_freq[c1][c2][c3][symbol] += coder->ponderation;
    coder->simple_freq[c1][c2][c3][coder->n_symbols] += coder->ponderation;

    if ((coder->simple_freq[c1][c2][c3][coder->n_symbols] % coder->update_periode) == 0) {
        for (int i = 0; i < coder->n_symbols; i++) {
            coder->freq[c1][c2][c3][i+1] = coder->freq[c1][c2][c3][i] + coder->simple_freq[c1][c2][c3][i];
        }
    }

    if (coder->simple_freq[c1][c2][c3][coder->n_symbols] == coder->context_window + coder->n_symbols) {
        if (coder->freq_window[c1][c2][c3][coder->n_symbols] != 0) {
            for (int i = 0; i < coder->n_symbols; i++) {
                coder->simple_freq[c1][c2][c3][i] -= coder->freq_window[c1][c2][c3][i] - coder->softening;
                coder->freq_window[c1][c2][c3][i] = coder->simple_freq[c1][c2][c3][i];   
            }
        }
        coder->simple_freq[c1][c2][c3][coder->n_symbols] -= coder->context_window;

        for (int i = 0; i <= coder->n_symbols; i++) {
            coder->freq_window[c1][c2][c3][i] = coder->simple_freq[c1][c2][c3][i];
        }
    }
}

void get_context(ArithmeticCoder *coder, uint64_t ***image, uint64_t z, uint64_t y, uint64_t x, uint64_t max_x, uint64_t *c1, uint64_t *c2, uint64_t *c3) {

    if (coder->context == NO_CONTEXT || (y == 0 & x == 0)) {
        *c1 = 0;
        *c2 = 0;
        *c3 = 0;
    } 
    else if (coder->context == CONTEXT_UP) {
        *c1 = 0;
        *c2 = 0;
        *c3 = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
    }
    else if (coder->context == CONTEXT_LEFT) {
        *c1 = 0;
        *c2 = 0;
        *c3 = x == 0 ? image[z][y-1][x] : image[z][y][x-1];
    }
    else if (coder->context == CONTEXT_UP_LEFT ) {
        *c1 = 0;
        *c2 = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
        *c3 = x == 0 ? image[z][y-1][x] : image[z][y][x-1];
    }
    else if (coder->context == CONTEXT_UP_LEFT_DIAGONAL) {
        *c1 = (x == 0 || y == 0) ? 0 : image[z][y-1][x-1];
        *c2 = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
        *c3 = x == 0 ? image[z][y-1][x] : image[z][y][x-1];
    }
    else if (coder->context == CONTEXT_UP_LEFT_SORTED) {
        *c1 = 0;
        *c2 = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
        *c3 = x == 0 ? image[z][y-1][x] : image[z][y][x-1];
        if (*c2 > *c3) {
            uint8_t aux = *c2;
            *c2 = *c3;
            *c3 = aux;
        }

    }
    else if (coder->context == CONTEXT_UP_LEFT_MIXED) {
        uint32_t mixed = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
        mixed += x == 0 ? image[z][y-1][x] : image[z][y][x-1];
        *c1 = 0;
        *c2 = 0;
        *c3 = mixed;
    }
    else if (coder->context == CONTEXT_UP_LEFT_DIAGONAL_MIXED) {
        uint32_t mixed = y == 0 && x > 0 ? image[z][y][x-1] * 3 : 0;
        mixed += y > 0 && x == 0 ? image[z][y-1][x] * 3 : 0;
        mixed += y > 0 && x > 0 ? image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] : 0;
        *c1 = 0;
        *c2 = 0;
        *c3 = mixed;
    }
    else if (coder->context == CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {
        uint32_t mixed = y == 0 && x > 0 ? image[z][y][x-1] * 4 : 0;
        mixed += y > 0 && x == 0 ? image[z][y-1][x] * 4 : 0;
        mixed += y > 0 && x > 0 && x == max_x ? image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] : 0;
        mixed += y > 0 && x > 0 && x < max_x ? image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1] : 0;

        *c1 = 0;
        *c2 = 0;
        *c3 = mixed;
    }
    else if (coder->context == CONTEXT_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 5;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 5;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] + image[z][y-1][x-1];
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1];
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        }

        *c1 = 0;
        *c2 = 0;
    }
    else if (coder->context == CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_WEIGHTED_MIXED) {
        uint32_t mixed = y == 0 && x > 0 ? image[z][y][x-1] * 5 : 0;
        mixed += y > 0 && x == 0 ? image[z][y-1][x] * 5 : 0;
        mixed += y > 0 && x > 0 && x == max_x ? image[z][y-1][x] * 3 + image[z][y][x-1] + image[z][y-1][x-1] : 0;
        mixed += y > 0 && x > 0 && x < max_x ? image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1] : 0;

        *c1 = 0;
        *c2 = 0;
        *c3 = mixed;
    }
    else if (coder->context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 6;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 6;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] * 2+ image[z][y-1][x-1];
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] * 2 + image[z][y-1][x-1];
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        }

        if (y > 1 && x > 1 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y][x-2] + image[z][y-1][x-1] + image[z][y-1][x+1];
        }

        *c1 = 0;
        *c2 = 0;
    }
    else if (coder->context == CONTEXT_ALL_TWO) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 10;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 10;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 4 + image[z][y][x-1] * 4+ image[z][y-1][x-1] * 2;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] * 3 + image[z][y-1][x-1] * 2 + image[z][y-1][x+1] * 2;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] * 2 + image[z][y-1][x] * 3 + image[z][y][x-1] * 3 + image[z][y-1][x-1] * 2;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 3 + image[z][y][x-1] * 2 + image[z][y-1][x-1] * 2 + image[z][y-1][x+1] * 2;
        }

        if (y > 1 && x > 1 && x < max_x) {
            *c3 = image[z][y-2][x-2] + image[z][y-2][x-1] + image[z][y-2][x] + image[z][y-2][x+1] + image[z][y-1][x-2] + image[z][y-1][x-1] + image[z][y-1][x] + image[z][y-1][x+1] + image[z][y][x-2] + image[z][y][x-1];
        }

        *c1 = 0;
        *c2 = 0;
    }
    else if (coder->context == CONTEXT_UP_LEFT_POWER) {
        uint64_t mixed = y == 0 ? image[z][y][x-1] * image[z][y][x-1] : image[z][y-1][x] * image[z][y-1][x];
        mixed += x == 0 ? image[z][y-1][x] * image[z][y-1][x] : image[z][y][x-1] * image[z][y][x-1];
        *c1 = 0;
        *c2 = 0;
        *c3 = (uint64_t)round(sqrt((double)mixed));
    }  else if (coder->context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED_POWER) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 6;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 6;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] * 2+ image[z][y-1][x-1];
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] * 2 + image[z][y-1][x-1];
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        }

        if (y > 1 && x > 1 && x < max_x) {
            uint64_t mixed = image[z][y-2][x] * image[z][y-2][x] + image[z][y-1][x] * image[z][y-1][x] + image[z][y][x-1] * image[z][y][x-1] +
            image[z][y][x-2] * image[z][y][x-2] + image[z][y-1][x-1] * image[z][y-1][x-1] + image[z][y-1][x+1] * image[z][y-1][x+1];
            *c3 = (uint64_t)round(sqrt((double)mixed));
        }

        *c1 = 0;
        *c2 = 0;
    } else if (coder->context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_REGRESSION) {
        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 3;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 4;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 4;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 5;
        }

        if (y > 1 && x > 1 && x < max_x) {
            if (x > 2) {
                double update_weight = (image[z][y][x-1] - PMemory) * 3E-8;
                PWeights[0] += update_weight * image[z][y-2][x-1];
                PWeights[1] += update_weight * image[z][y-1][x-1];
                PWeights[2] += update_weight * image[z][y][x-2];
                PWeights[3] += update_weight * image[z][y][x-3];
                PWeights[4] += update_weight * image[z][y-1][x-2];
                PWeights[5] += update_weight * image[z][y-1][x];

            }

            PMemory = image[z][y-2][x] * PWeights[0] + image[z][y-1][x] * PWeights[1] + image[z][y][x-1] * PWeights[2] + image[z][y][x-2] * PWeights[3] + image[z][y-1][x-1] * PWeights[4] + image[z][y-1][x+1] * PWeights[5];
           // *c3 = image[z][y-2][x] * (int)round(PWeights[0] * 6) + image[z][y-1][x] * (int)round(PWeights[1] * 6) + image[z][y][x-1] * (int)round(PWeights[2] * 6) + image[z][y][x-2] * (int)round(PWeights[3] * 6) + image[z][y-1][x-1] * (int)round(PWeights[4] * 6) + image[z][y-1][x+1] * (int)round(PWeights[5] * 6);
            //*c3 = (int)round((6.0 * (float)*c3) / ((int)round(PWeights[0] * 6) + (int)round(PWeights[1] * 6) + (int)round(PWeights[2] * 6) + (int)round(PWeights[3] * 6) + (int)round(PWeights[4] * 6) + (int)round(PWeights[5] * 6)));
            *c3 = (int)round(PMemory);
            if (*c3 > coder->n_symbols - 1) {
                *c3 = coder->n_symbols - 1;
            } else if(*c3 < 0) {
                *c3 = 0;
            }
            
        }

        *c1 = 0;
        *c2 = 0;
    }  else if (coder->context == CONTEXT_ALL_REGRESSION) {
        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 3;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 4;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 4;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 5;
        }

        if (y > 3 && x > 3 && x < max_x) {
            if (x > 4) {
                double update_weight = (image[z][y][x-1] - PMemory) * 3E-8;
                for (int i = 0; i < 18; i++) {
                    PWeights2[i] += update_weight * image[z][y - 3 + (i / 5)][x - 4 + (i % 5)];
                }
            }
            PMemory = 0;

            for (int i = 0; i < 18; i++) {
                PMemory += image[z][y - 3 + (i / 5)][x - 3 + (i % 5)] * PWeights2[i];
            }
            *c3 = (uint64_t)round(PMemory);

            if (*c3 > coder->n_symbols - 1) {
                *c3 = coder->n_symbols - 1;
            } else if(*c3 < 0) {
                *c3 = 0;
            }
            
        }

        *c1 = 0;
        *c2 = 0;
    }  else if (coder->context == CONTEXT_PREDICTOR) {
        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 3;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 4;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 4;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 5;
        }

        if (y > 3 && x > 3 && x < max_x) {
            *c3 = (image[z][y][x-1] * 3 + image[z][y][x-2] * 2 + image[z][y][x-3] + image[z][y-1][x+1] * 2 + 
                  image[z][y-1][x] * 2 + image[z][y-1][x-1] + image[z][y-1][x-2] + image[z][y-1][x-3] + 
                  image[z][y-2][x] + image[z][y-2][x-1] + image[z][y-2][x-2] + image[z][y-2][x-3] +
                  image[z][y-3][x] + image[z][y-3][x-1] + image[z][y-3][x-2] + image[z][y-3][x-3]) / 21;
            
        }


        *c1 = 0;
        *c2 = 0;
    } else if (coder->context == CONTEXT_ALL_REGRESSION_MORE) {
        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 3;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 4;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 4;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 5;
        }

        if (y > 4 && x > 3 && x < max_x) {
            if (x > 4) {
                double update_weight = (image[z][y][x-1] - PMemory) * 3E-8;
                for (int i = 0; i < 23; i++) {
                    PWeights3[i] += update_weight * image[z][y - 4 + (i / 5)][x - 4 + (i % 5)];
                }
            }
            PMemory = 0;

            for (int i = 0; i < 23; i++) {
                PMemory += image[z][y - 4 + (i / 5)][x - 3 + (i % 5)] * PWeights3[i];
            }
            *c3 = (uint64_t)round(PMemory);

            if (*c3 > coder->n_symbols - 1) {
                *c3 = coder->n_symbols - 1;
            } else if(*c3 < 0) {
                *c3 = 0;
            }
            
        }

        *c1 = 0;
        *c2 = 0;
    } else if (coder->context == CONTEXT_MAX) {
        *c3 = 0;
         if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y > 0 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x];
        } else if (y > 0 && x > 0) {
            *c3 = image[z][y][x-1];
            *c3 = *c3 > image[z][y-1][x] ? *c3 : image[z][y-1][x];
            *c3 = *c3 > image[z][y-1][x-1] ? *c3 : image[z][y-1][x-1];
            *c3 = *c3 > image[z][y-1][x+1] ? *c3 : image[z][y-1][x+1];
        }

        *c3 = *c3;
        *c2 = 0;
        *c1 = 0;
    }
    else if (coder->context == CONTEXT_EXTREME_MIXED) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 21;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 21;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 10 + image[z][y][x-1] * 10 + image[z][y-1][x-1];
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 10 + image[z][y][x-1] * 6 + image[z][y-1][x-1] * 3 + image[z][y-1][x+1] * 2;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] * 3 + image[z][y-1][x] * 8 + image[z][y][x-1] * 8 + image[z][y-1][x-1] * 2;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] * 3 + image[z][y-1][x] * 8 + image[z][y][x-1] * 6 + image[z][y-1][x-1] * 2 + image[z][y-1][x+1] * 2;
        }

        if (y > 1 && x > 1 && x < max_x) {
            *c3 = image[z][y-2][x-2] * 2 + image[z][y-2][x-1] * 2 + image[z][y-2][x] * 2 + image[z][y-2][x+1] * 2 +
                  image[z][y-1][x-2] * 2 + image[z][y-1][x-1] * 2 + image[z][y-1][x] * 2 + image[z][y-2][x+1] * 2 + 
                  image[z][y-0][x-2] * 2 + image[z][y-0][x-1] * 3; // CONTEXT PIXEL;
        }

        if (y > 2 && x > 2 && x < max_x - 1) {
            *c3 = image[z][y-3][x-3] + image[z][y-3][x-2] + image[z][y-3][x-1] + image[z][y-3][x] + image[z][y-3][x+1] + image[z][y-3][x+2] +
                  image[z][y-2][x-3] + image[z][y-2][x-2] + image[z][y-2][x-1] + image[z][y-2][x] + image[z][y-2][x+1] + image[z][y-2][x+2] +
                  image[z][y-1][x-3] + image[z][y-1][x-2] + image[z][y-1][x-1] + image[z][y-1][x] + image[z][y-2][x+1] + image[z][y-2][x+2] + 
                  image[z][y-0][x-3] + image[z][y-0][x-2] + image[z][y-0][x-1]; // CONTEXT PIXEL;
        }
 
        *c1 = 0;
        *c2 = 0;
    }
}

void get_max_context(ArithmeticCoder *coder, int context, uint64_t *max_c1, uint64_t *max_c2, uint64_t *max_c3) {
    if (context == NO_CONTEXT) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = 1;
    } else if (context == CONTEXT_LEFT || context == CONTEXT_UP) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols;
    } else if (context == CONTEXT_UP_LEFT) {
        *max_c1 = 1;
        *max_c2 = coder->n_symbols;
        *max_c3 = coder->n_symbols;
    } else if (context == CONTEXT_UP_LEFT_MIXED){
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 2;
    } else if (context == CONTEXT_UP_LEFT_SORTED){
        *max_c1 = 1;
        *max_c2 = coder->n_symbols;
        *max_c3 = coder->n_symbols;
    } else if (context == CONTEXT_UP_LEFT_DIAGONAL) {
        *max_c1 = coder->n_symbols;
        *max_c2 = coder->n_symbols;
        *max_c3 = coder->n_symbols;
    } else if (context == CONTEXT_UP_LEFT_DIAGONAL_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 3;
    } else if (context == CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 4;
    } else if (context == CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_WEIGHTED_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 5;
    } else if (context == CONTEXT_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 5;
    } else if (context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 6;
    } else if (context == CONTEXT_ALL_TWO) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 10;
    } else if (context == CONTEXT_UP_LEFT_POWER){
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 2;
    }else if (context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED_POWER) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 6;
    } else if(context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_REGRESSION) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols;
    } else if (context == CONTEXT_ALL_REGRESSION) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols;
    } else if (context == CONTEXT_PREDICTOR) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols;
    } else if (context == CONTEXT_ALL_REGRESSION_MORE) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols;
    } else if (context == CONTEXT_MAX) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols;
    } else if (context == CONTEXT_EXTREME_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = coder->n_symbols * 21;
    }

}


/**
 * ENCODER FUNCTIONS
 */
static void write_bit(ArithmeticCoder *coder, uint8_t bit) {
    coder->bit_buffer = (coder->bit_buffer << 1) | (bit & 1);
    coder->bit_count++;
    
    // Flush the buffer if it's full
    if (coder->bit_count == 8) {
        fputc(coder->bit_buffer, stdout);
        coder->bit_buffer = 0;
        coder->bit_count = 0;
    }
}

int init_coder(ArithmeticCoder *coder, int n_symbols, int context, int context_window, int update_periode, int softening, int ponderation) {
    coder->n_symbols = n_symbols;
    coder->context = context;
    coder->context_window = context_window;
    coder->update_periode = update_periode;
    coder->softening = softening;
    coder->ponderation = ponderation;

    coder->low = 0;
    coder->high = TOP_VALUE;
    coder->scale3 = 0;
    coder->bit_count = 0;

    uint64_t max_c1, max_c2, max_c3;

    get_max_context(coder, context, &max_c1, &max_c2, &max_c3);

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->freq) != 0) {
        return -1;
    }

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->freq_window) != 0) {
        return -1;
    }

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->simple_freq) != 0) {
        return -1;
    }


    for (int c1 = 0; c1 < max_c1; c1++) {
    for (int c2 = 0; c2 < max_c2; c2++) {
    for (int c3 = 0; c3 < max_c3; c3++) {
        for (int i = 0; i <= n_symbols; i++) {
            coder->simple_freq[c1][c2][c3][i] = coder->softening;
            coder->freq[c1][c2][c3][i] = i * coder->softening;
            coder->freq_window[c1][c2][c3][i] = 0;
        }
        coder->simple_freq[c1][c2][c3][n_symbols] = coder->softening * n_symbols;

    } 
    }
    }


    return 0;
}

int encode_symbol(ArithmeticCoder *coder, uint8_t symbol, uint64_t c1, uint64_t c2, uint64_t c3) {
    uint64_t range = coder->high - coder->low + 1;

    // Calculate new bounds using 64-bit to avoid overflow
    coder->high = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][symbol + 1]) / coder->freq[c1][c2][c3][coder->n_symbols]) - 1);
    coder->low  = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][symbol]) / coder->freq[c1][c2][c3][coder->n_symbols]));

    while (((coder->low ^ coder->high) & HALF) == 0) {
        write_bit(coder, (coder->low >> (PRECISION - 1)) & 1);
        while (coder->scale3 > 0) {
            write_bit(coder, !((coder->low >> (PRECISION - 1)) & 1));
            coder->scale3--;
        }

        coder->low = (coder->low << 1) & TOP_VALUE;
        coder->high = ((coder->high << 1) & TOP_VALUE) | 1;
    } 
    
    // E3 condition
    while ((coder->low >> (PRECISION - 2) & 1 ) && !((coder->high >> (PRECISION - 2)) & 1)) {
        coder->low = (coder->low & (1 << (PRECISION - 1))) | ((coder->low & (TOP_VALUE >> 2)) << 1);
        coder->high = (coder->high & (1 << (PRECISION - 1))) | ((coder->high & (TOP_VALUE >> 2)) << 1) | 1;
        coder->scale3++;
    }

    return 0;
}

int encode_bit(ArithmeticCoder *coder, uint8_t bit, uint64_t c1, uint64_t c2, uint64_t c3) {
    uint64_t range = coder->high - coder->low + 1;

    if (bit == 0) {
        coder->high = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][0]) / coder->freq[c1][c2][c3][coder->n_symbols]) - 1);
    } else {
        coder->low = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][0]) / coder->freq[c1][c2][c3][coder->n_symbols]));
    }

    if (coder->high == coder->low) {
        for(uint8_t i = PRECISION - 1; i > 0; i--) {
            write_bit(coder, coder->low >> i);
        }

        coder->low = 0;
        coder->high = TOP_VALUE;
    }

    return 0;
}

void finalize_encoding(ArithmeticCoder *coder) {
    write_bit(coder, (coder->low >> (PRECISION - 1)) & 1);

    while (coder->scale3 > 0)
    {
        write_bit(coder, 1);
        coder->scale3--;
    }
    
    for(int8_t i = PRECISION - 2; i >= 0; i--) {
        write_bit(coder, coder->low >> i);
    }

    // Flush any remaining bits in the buffer
    if (coder->bit_count > 0) {
        coder->bit_buffer <<= (8 - coder->bit_count);
        fputc(coder->bit_buffer, stdout);
    }

    uint64_t max_c1, max_c2, max_c3;
    get_max_context(coder, coder->context, &max_c1, &max_c2, &max_c3);
    free_freq(max_c1, max_c2, max_c3, &coder->freq);
}

/**
 * DECODER FUNCTIONS
 */
uint8_t read_bit(ArithmeticCoder *coder) {
    if ((coder->bits_count & 7) == 0) {
        int byte = fgetc(stdin);
        if (byte == EOF) byte = 0;
        coder->input_byte = (uint8_t)byte;
    }
    uint8_t bit = (coder->input_byte >> 7) & 1;
    coder->input_byte <<= 1;
    coder->bits_count++;
    return bit;
}

int init_decoder(ArithmeticCoder *coder, int n_symbols, int context, int context_window, int update_periode, int softening, int ponderation) {
    coder->n_symbols = n_symbols;
    coder->context = context;
    coder->context_window = context_window;
    coder->update_periode = update_periode;
    coder->softening = softening;
    coder->ponderation = ponderation;

    coder->low = 0;
    coder->high = TOP_VALUE;
    coder->word_buffer = 0;
    coder->bits_count = 0;

    uint64_t max_c1, max_c2, max_c3;

    get_max_context(coder, context, &max_c1, &max_c2, &max_c3);

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->freq) != 0) {
        return -1;
    }

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->freq_window) != 0) {
        return -1;
    }

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->simple_freq) != 0) {
        return -1;
    }
    
    for (int c1 = 0; c1 < max_c1; c1++) {
    for (int c2 = 0; c2 < max_c2; c2++) {
    for (int c3 = 0; c3 < max_c3; c3++) {
        for (int i = 0; i <= n_symbols; i++) {
            coder->simple_freq[c1][c2][c3][i] = coder->softening;
            coder->freq[c1][c2][c3][i] = i * coder->softening;
            coder->freq_window[c1][c2][c3][i] = 0;
        }
    }
    }
    }

    for (int i = 0; i < PRECISION; i++) {
        coder->word_buffer = (coder->word_buffer << 1) | read_bit(coder);
    }

    return 0;

}

uint8_t decode_symbol(ArithmeticCoder *coder, uint64_t c1, uint64_t c2, uint64_t c3) {
    uint64_t range = coder->high - coder->low + 1;

    uint32_t position = (uint32_t)((((uint64_t)(coder->word_buffer - coder->low + 1) * coder->freq[c1][c2][c3][coder->n_symbols]) - 1) / range);

    // Binary Search
    uint32_t left = 0, right = coder->n_symbols, mid;
    while (left < right) {
        mid = left + (right - left) / 2;
        if (coder->freq[c1][c2][c3][mid + 1] <= position) {
            left = mid + 1;
        } else {
            right = mid;
        }
    }
    uint8_t symbol = (uint8_t)left;

    coder->high = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][symbol + 1]) / coder->freq[c1][c2][c3][coder->n_symbols]) - 1);
    coder->low  = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][symbol]) / coder->freq[c1][c2][c3][coder->n_symbols]));

    while (((coder->low ^ coder->high) & HALF) == 0)  {
        coder->word_buffer = ((coder->word_buffer << 1) & TOP_VALUE) | read_bit(coder);
        coder->low = (coder->low << 1) & TOP_VALUE;
        coder->high = ((coder->high << 1) & TOP_VALUE) | 1;
    }
    
    // E3 condition
    while ((coder->low >> (PRECISION - 2) & 1 ) && !((coder->high >> (PRECISION - 2)) & 1)) {
        coder->low = (coder->low & (1 << (PRECISION - 1))) | ((coder->low & (TOP_VALUE >> 2)) << 1);
        coder->high = (coder->high & (1 << (PRECISION - 1))) | ((coder->high & (TOP_VALUE >> 2)) << 1) | 1;

        coder->word_buffer = (((coder->word_buffer << 1) & TOP_VALUE) | read_bit(coder)) ^ (1 << (PRECISION - 1));

    }

    return symbol;
}

void finalize_decoding(ArithmeticCoder *coder) {
    uint64_t max_c1, max_c2, max_c3;
    get_max_context(coder, coder->context, &max_c1, &max_c2, &max_c3);
    free_freq(max_c1, max_c2, max_c3, &coder->freq);
}


int main(int argc, char *argv[]) {
    if (argc != 10) {
        fprintf(stderr, "Usage: %s\n <n_words> <context> <context-window> <update-freq> <softening> <ponderation> <model> <precision> <measure-point>", argv[0]);
        return 1;
    }
    
    // Obtener el número de palabras
    int words = atoi(argv[1]);

    // Obtener el contexto como string
    char *context_str = argv[2];

    // Convertir el contexto a una lista de enteros
    int context[16];
    int context_size = 0;
    
    
    char *token = strtok(context_str, ",");
    while (token != NULL && context_size < 16) {
        context[context_size++] = atoi(token);
        token = strtok(NULL, ",");
    }

    // Obtener la ventana de contexto
    int context_window = atoi(argv[3]);

    int update_periode = atoi(argv[4]);
    
    int softening = atoi(argv[5]);

    int ponderation = atoi(argv[6]);

    int model = atoi(argv[7]);

    int precision = atoi(argv[8]);

    double measure_point = atof(argv[9]);

    Header header;
    if (header_parse_stdin(&header) != 0) return 1;
    header.data = header.state == COMPRESS ? BITSTREAM : RESIDUAL;
    print_header(&header);

    DataPacket inputData = {0}; 

    uint8_t it = 0;

    while (body_parse_stdin(&inputData) == 0) {
        DataPacket outputBody = {0};
        outputBody.id = 0;
        outputBody.type = DATA_TYPE_BITSTREAM;
        outputBody.bits = inputData.bits;
 
        if (header.state == COMPRESS) {
            if ((inputData.type != DATA_TYPE_IMAGE) && (inputData.type != DATA_TYPE_RESIDUALS)) {
                continue; // Implement a forward data
            }    
            
            ArithmeticCoder coderDkl; 
            uint64_t c1, c2, c3;
    
            uint64_t ***imageData = NULL;

            if (get_image_from_stdin(&inputData, header, &imageData) != 0) {
                printf("Error generating image\n");
                return 1;
            }

            //header.x = 64;
            //header.y = 64;

            // Calculem P(x)
            init_coder(&coderDkl, inputData.bits == 0 ? words : 1 << inputData.bits, context[it % context_size], (int)1E15, 1, 0, 1);
            
            for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                    for (uint64_t x = 0; x < header.x; x++) {
                        get_context(&coderDkl, imageData, z, y, x, header.x -1, &c1, &c2, &c3);
                        update_freq(&coderDkl, imageData[z][y][x], c1, c2, c3);
                    }
                }
            }
            
            double Hpx = 0;


            uint64_t max_c1, max_c2, max_c3;
            get_max_context(&coderDkl, coderDkl.context, &max_c1, &max_c2, &max_c3);

            for (uint64_t i = 0; i < max_c1; i++) {
                for (uint64_t j = 0; j < max_c2; j++) {
                    for (uint64_t k = 0; k < max_c3; k++) {
                        if (coderDkl.simple_freq[i][j][k][1 << inputData.bits] != 0) {
                            double Hpxc = 0;
                            for (uint64_t v = 0; v < 1 << inputData.bits; v++) {
                                double Pxy = (double)(coderDkl.simple_freq[i][j][k][v]) / coderDkl.simple_freq[i][j][k][1 << inputData.bits];
                                if (Pxy != 0) {
                                    Hpxc -= Pxy * log2(Pxy);
                                }
                            }
                            Hpx += Hpxc * ((double)coderDkl.simple_freq[i][j][k][1 << inputData.bits] / (header.z * header.y * header.x));
                        }
                    }
                }
            }

            ArithmeticCoder coder; 

            init_coder(&coder, inputData.bits == 0 ? words : 1 << inputData.bits, context[it % context_size], context_window, update_periode, softening, ponderation);

            outputBody.type = DATA_TYPE_BITSTREAM;
            start_body(&outputBody, stdout);

            if(model == 0) { // Coding Cost P
                for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                for (uint64_t x = 0; x < header.x; x++) {
                    get_context(&coder, imageData, z, y, x, header.x -1, &c1, &c2, &c3);
                    if ((z * header.y * header.x + y * header.x + x) % precision == 0) {
                        fprintf(stderr, "%f\n", -log2((float)coderDkl.simple_freq[c1][c2][c3][imageData[z][y][x]] / coderDkl.simple_freq[c1][c2][c3][1 << inputData.bits]));
                    }
                }
                }
                }
            } 
            else if(model == 1) { // coding cost avg P (Exactly entropy)
                for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                for (uint64_t x = 0; x < header.x; x++) {
                    if ((z * header.y * header.x + y * header.x + x) % precision == 0) {
                        fprintf(stderr, "%f\n", Hpx);
                    }
                }
                }
                }
            } 
            else if(model == 2) { // CODING COST Qi
                for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                for (uint64_t x = 0; x < header.x; x++) {
                    get_context(&coder, imageData, z, y, x, header.x -1, &c1, &c2, &c3);
                    if ((z * header.y * header.x + y * header.x + x) % precision == 0) {
                        fprintf(stderr, "%f\n", (-log2((double)(coder.simple_freq[c1][c2][c3][imageData[z][y][x]]) / coder.simple_freq[c1][c2][c3][1 << inputData.bits])));
                    }
                    update_freq(&coder, imageData[z][y][x], c1, c2, c3);
                }
                }
                }
            } 
            else if(model == 3) { // Coding Cost AVG Qi (Quasy Entropy)
                
                for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                for (uint64_t x = 0; x < header.x; x++) {
                    get_context(&coder, imageData, z, y, x, header.x -1, &c1, &c2, &c3);
                    if ((z * header.y * header.x + y * header.x + x) % precision == 0) {
                        double Hqix = 0;
                        for (uint64_t i = 0; i < max_c1; i++) {
                        for (uint64_t j = 0; j < max_c2; j++) {
                        for (uint64_t k = 0; k < max_c3; k++) {
                            if ((double)coderDkl.simple_freq[i][j][k][1 << inputData.bits] != 0) {
                                double Hqixc = 0;
                                for (uint64_t v = 0; v < 1 << inputData.bits; v++) {
                                    double Qxy = (double)(coder.simple_freq[i][j][k][v]) / coder.simple_freq[i][j][k][1 << inputData.bits];
                                    double Pxy = (double)(coderDkl.simple_freq[i][j][k][v]) / coderDkl.simple_freq[i][j][k][1 << inputData.bits];
                                    Hqixc -= Pxy * log2(Qxy);
                                }
                                Hqix += Hqixc * ((double)coderDkl.simple_freq[i][j][k][1 << inputData.bits] / (header.z * header.y * header.x));
                            }
                        }
                        }
                        }

                        fprintf(stderr, "%f\n", Hqix);
                    }
                    update_freq(&coder, imageData[z][y][x], c1, c2, c3);
                }
                }
                }
            } 
            else if(model == 4) { // Coding cost avg Q^i (Quasy entropy)
                init_coder(&coder, inputData.bits == 0 ? words : 1 << inputData.bits, context[it % context_size], context_window, 1, 0, 1);
                float pointY;

                for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                for (uint64_t x = 0; x < header.x; x++) {
                    get_context(&coder, imageData, z, y, x, header.x -1, &c1, &c2, &c3);
                    if ((z * header.y * header.x + y * header.x + x) == (int)(header.z * header.y * header.x * measure_point)) {
                        double Hqix = 0;
                        for (uint64_t i = 0; i < max_c1; i++) {
                        for (uint64_t j = 0; j < max_c2; j++) {
                        for (uint64_t k = 0; k < max_c3; k++) {                     
                            if ((double)coderDkl.simple_freq[i][j][k][1 << inputData.bits] != 0) {
                                double Hqixc = 0;
                                for (uint64_t v = 0; v < 1 << inputData.bits; v++) {
                                    double Pxy = (double)(coderDkl.simple_freq[i][j][k][v]) / coderDkl.simple_freq[i][j][k][1 << inputData.bits];
                                    double Qxy = ((double)(coder.simple_freq[i][j][k][v]) + 1) / (coder.simple_freq[i][j][k][1 << inputData.bits] + (1 << inputData.bits));
                                    Hqixc -= Pxy * log2(Qxy);
                                }
                                Hqix += Hqixc * ((double)coderDkl.simple_freq[i][j][k][1 << inputData.bits] / (header.z * header.y * header.x));
                            }
                        }
                        }
                        }
                        pointY = Hqix;
                    }

                    update_freq(&coder, imageData[z][y][x], c1, c2, c3);
                }
                }
                }

                double endPoint = 0;

                for (uint64_t i = 0; i < max_c1; i++) {
                for (uint64_t j = 0; j < max_c2; j++) {
                for (uint64_t k = 0; k < max_c3; k++) {
                    if ((double)coderDkl.simple_freq[i][j][k][1 << inputData.bits] != 0) {
                        double Hqixc = 0;
                        for (uint64_t v = 0; v < 1 << inputData.bits; v++) {
                            double Pxy = (double)(coderDkl.simple_freq[i][j][k][v]) / coderDkl.simple_freq[i][j][k][1 << inputData.bits];
                            double Qxy = ((double)(coder.simple_freq[i][j][k][v]) + 1) / (coder.simple_freq[i][j][k][1 << inputData.bits] + (1 << inputData.bits));
                            Hqixc -= Pxy * log2(Qxy);
                        }
                        endPoint += Hqixc * ((double)coderDkl.simple_freq[i][j][k][1 << inputData.bits] / (header.z * header.y * header.x));
                    }
                }
                }
                }

                double mp = measure_point;
                double x = inputData.bits;
                double y = endPoint;
                double z = pointY;


                double b = (double)((-x + mp * x - mp * y + z) * (-x + mp * x - mp * y + z)) / ((-1 + mp) * mp * (x - y) * (x - z) * (y - z));
                double c = -(double)(mp *(y - z)) / (x - mp * x + mp * y - z);
                double d = (double)(- x * y + mp * x * z + y * z - mp * y * z) / (- x + mp * x - mp * y + z); 

                for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                for (uint64_t x = 0; x < header.x; x++) {
                    if ((z * header.y * header.x + y * header.x + x) % precision == 0) {
                        double percentage = (double)(z * header.y * header.x + y * header.x + x) / (double)(header.x * header.y * header.z);
                        fprintf(stderr, "%f\n", (double)((double)(1.0) / (double)(b * (percentage + c))) + d);    
                    }
                }
                }
                }
            }

            finalize_encoding(&coder);
            finalize_encoding(&coderDkl);
            end_body(&outputBody, stdout);
            free_image(imageData, header);
            fprintf(stderr, "--\n");
    
        }
        it++;
    }

    return 0;
}
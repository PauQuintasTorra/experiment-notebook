#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils/header.h"
#include "utils/body.h"


void swap_endianness(void* buffer, size_t count) {
    uint8_t* data = (uint8_t*)buffer;
    uint8_t temp;
    for (size_t i = 0; i < count; i++) {
        temp = data[i * 2];
        data[i * 2] = data[i * 2 + 1];
        data[i * 2 + 1] = temp;
    }
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <output_file> <header>\n", argv[0]);
        return 1;
    }

    char *output_filename = argv[1];
    int with_header = atoi(argv[2]);

    FILE *output_file = fopen(output_filename, "wb");
    if (!output_file) {
        perror("Error al crear el archivo de salida");
        return 1;
    }

    Header header;
    if (header_parse_stdin(&header) != 0) {
        return 1;
    }

    // printf("Header recibido: \n");
    // print_header(&header);

    DataPacket imageData = {0}; 
    char buffer[1024];
    size_t bytes_read;

    if (header.state == COMPRESS){
        if (with_header) {
            header.state = DECOMPRESS;
            store_header(&header, output_file);
            while ((bytes_read = fread(buffer, 1, sizeof(buffer), stdin)) > 0) {
                fwrite(buffer, 1, bytes_read, output_file);
            }
        } else {
            while(body_parse_stdin(&imageData) == 0) {
                while ((bytes_read = body_fread(&imageData, buffer, 1, sizeof(buffer), stdin)) > 0) {
                    
                    if(header.bits > 8 && header.endian == 'b' && imageData.endian == 'l') {
                        swap_endianness(buffer, bytes_read * 8 / header.bits);
                    }
                    
                    fwrite(buffer, 1, bytes_read, output_file);
                }
            }
        }
    

    } else {
        DataPacket imageData = {0}; 
        char buffer[1024];
        size_t bytes_read;
        while(body_parse_stdin(&imageData) == 0) {
            while ((bytes_read = body_fread(&imageData, buffer, 1, sizeof(buffer), stdin)) > 0) {
                
                if(header.bits > 8 && header.endian == 'b' && imageData.endian == 'l') {
                    swap_endianness(buffer, bytes_read * 8 / header.bits);
                }
                
                fwrite(buffer, 1, bytes_read, output_file);
            }
        }
    }

    fclose(output_file);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

#include "utils/header.h"
#include "utils/body.h"
#include "utils/image_converter.h"
#include "utils/context.h"

#define PRECISION 24

#define TOP_VALUE      ((1 << PRECISION) - 1)
#define HALF           (1 << (PRECISION - 1))


typedef struct {
    // User information
    uint32_t n_symbols;
    ContextType context;
    uint32_t context_window;
    uint32_t update_periode;
    uint32_t softening;
    uint32_t ponderation;

    // Global data
    uint32_t low, high;
    uint64_t scale3;
    uint32_t ****simple_freq;
    uint32_t ****freq;
    uint32_t ****freq_window;

    // Encoder buffers
    uint8_t bit_buffer;
    uint64_t bit_count;
    
    // Decoder state
    uint32_t word_buffer;
    uint8_t input_byte;
    uint64_t bits_count;
} ArithmeticCoder;


/**
 * Global funcitons
 */

 int initialize_freq(uint64_t max_c1, uint64_t max_c2, uint64_t max_c3, uint16_t n_symbols, uint32_t *****freq) {
    *freq = (uint32_t ****)malloc(max_c1 * sizeof(uint32_t ***));

    if (!*freq) return 1;

    for (int i = 0; i < max_c1; i++) {
        (*freq)[i] = (uint32_t ***)malloc(max_c2 * sizeof(uint32_t **));
        if (!(*freq)[i]) {
            for (int j = 0; j < i; j++) {
                free((*freq)[j]);
            }
            free(*freq);
            return 1;
        }

        for (int j = 0; j < max_c2; j++) {
            (*freq)[i][j] = (uint32_t **)malloc(max_c3 * sizeof(uint32_t *));
            if (!(*freq)[i][j]) {
                for (int k = 0; k < j; k++) {
                    free((*freq)[i][k]);
                }
                free((*freq)[i]);
                for (int k = 0; k < i; k++) {
                    free((*freq)[k]);
                }
                free(*freq);
                return 1;
            }

            for (int k = 0; k < max_c3; k++) {
                (*freq)[i][j][k] = (uint32_t *)malloc((n_symbols + 1) * sizeof(uint32_t));
                if (!(*freq)[i][j][k]) {
                    for (int l = 0; l < k; l++) {
                        free((*freq)[i][j][l]);
                    }
                    free((*freq)[i][j]);
                    for (int l = 0; l < j; l++) {
                        for (int m = 0; m < max_c3; m++) {
                            free((*freq)[i][l][m]);
                        }
                        free((*freq)[i][l]);
                    }
                    free((*freq)[i]);
                    for (int l = 0; l < i; l++) {
                        for (int m = 0; m < max_c2; m++) {
                            for (int n = 0; n < max_c3; n++) {
                                free((*freq)[l][m][n]);
                            }
                            free((*freq)[l][m]);
                        }
                        free((*freq)[l]);
                    }
                    free(*freq);
                    return 1;
                }
            }
        }
    }
    return 0;
}

void free_freq(uint64_t max_c1, uint64_t max_c2, uint64_t max_c3, uint32_t *****freq) {
    if (!freq || !*freq) return;

    for (int i = 0; i < max_c1; i++) {
        if (!(*freq)[i]) continue;

        for (int j = 0; j < max_c2; j++) {
            if (!(*freq)[i][j]) continue;

            for (int k = 0; k < max_c3; k++) {
                free((*freq)[i][j][k]);
            }
            free((*freq)[i][j]);
        }
        free((*freq)[i]);
    }
    free(*freq);
    *freq = NULL;
}

void update_freq(ArithmeticCoder *coder, uint16_t symbol, uint64_t c1, uint64_t c2, uint64_t c3) {
    coder->simple_freq[c1][c2][c3][symbol] += coder->ponderation;
    coder->simple_freq[c1][c2][c3][coder->n_symbols] += coder->ponderation;

    if ((coder->simple_freq[c1][c2][c3][coder->n_symbols] % coder->update_periode) == 0) {
        for (int i = 0; i < coder->n_symbols; i++) {
            coder->freq[c1][c2][c3][i+1] = coder->freq[c1][c2][c3][i] + coder->simple_freq[c1][c2][c3][i];
        }
    }

    if (coder->simple_freq[c1][c2][c3][coder->n_symbols] == coder->context_window + coder->n_symbols) {
        if (coder->freq_window[c1][c2][c3][coder->n_symbols] != 0) {
            for (int i = 0; i < coder->n_symbols; i++) {
                coder->simple_freq[c1][c2][c3][i] -= coder->freq_window[c1][c2][c3][i] - coder->softening;
                coder->freq_window[c1][c2][c3][i] = coder->simple_freq[c1][c2][c3][i];   
            }
        }
        coder->simple_freq[c1][c2][c3][coder->n_symbols] -= coder->context_window;

        for (int i = 0; i <= coder->n_symbols; i++) {
            coder->freq_window[c1][c2][c3][i] = coder->simple_freq[c1][c2][c3][i];
        }
    }
}



/**
 * ENCODER FUNCTIONS
 */
static void write_bit(ArithmeticCoder *coder, uint8_t bit) {
    coder->bit_buffer = (coder->bit_buffer << 1) | (bit & 1);
    coder->bit_count++;
    
    // Flush the buffer if it's full
    if (coder->bit_count == 8) {
        fputc(coder->bit_buffer, stdout);
        coder->bit_buffer = 0;
        coder->bit_count = 0;
    }
}

int init_coder(ArithmeticCoder *coder, int n_symbols, int context, int context_window, int update_periode, int softening, int ponderation) {
    coder->n_symbols = n_symbols;
    coder->context = context;
    coder->context_window = context_window;
    coder->update_periode = update_periode;
    coder->softening = softening;
    coder->ponderation = ponderation;

    coder->low = 0;
    coder->high = TOP_VALUE;
    coder->scale3 = 0;
    coder->bit_count = 0;

    uint64_t max_c1, max_c2, max_c3;

    get_max_context(coder->n_symbols, context, &max_c1, &max_c2, &max_c3);


    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->freq) != 0) {
        return -1;
    }

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->freq_window) != 0) {
        return -1;
    }

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->simple_freq) != 0) {
        return -1;
    }


    for (int c1 = 0; c1 < max_c1; c1++) {
    for (int c2 = 0; c2 < max_c2; c2++) {
    for (int c3 = 0; c3 < max_c3; c3++) {
        for (int i = 0; i <= n_symbols; i++) {
            coder->simple_freq[c1][c2][c3][i] = coder->softening;
            coder->freq[c1][c2][c3][i] = i * coder->softening;
            coder->freq_window[c1][c2][c3][i] = 0;
        }
    } 
    }
    }


    return 0;
}

int encode_symbol(ArithmeticCoder *coder, uint16_t symbol, uint64_t c1, uint64_t c2, uint64_t c3) {
    uint64_t range = coder->high - coder->low + 1;

    // Calculate new bounds using 64-bit to avoid overflow
    coder->high = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][symbol + 1]) / coder->freq[c1][c2][c3][coder->n_symbols]) - 1);
    coder->low  = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][symbol]) / coder->freq[c1][c2][c3][coder->n_symbols]));

    while (((coder->low ^ coder->high) & HALF) == 0) {
        write_bit(coder, (coder->low >> (PRECISION - 1)) & 1);
        while (coder->scale3 > 0) {
            write_bit(coder, !((coder->low >> (PRECISION - 1)) & 1));
            coder->scale3--;
        }

        coder->low = (coder->low << 1) & TOP_VALUE;
        coder->high = ((coder->high << 1) & TOP_VALUE) | 1;
    } 
    
    // E3 condition
    while ((coder->low >> (PRECISION - 2) & 1 ) && !((coder->high >> (PRECISION - 2)) & 1)) {
        coder->low = (coder->low & (1 << (PRECISION - 1))) | ((coder->low & (TOP_VALUE >> 2)) << 1);
        coder->high = (coder->high & (1 << (PRECISION - 1))) | ((coder->high & (TOP_VALUE >> 2)) << 1) | 1;
        coder->scale3++;
    }

    return 0;
}

void finalize_encoding(ArithmeticCoder *coder) {
    write_bit(coder, (coder->low >> (PRECISION - 1)) & 1);

    while (coder->scale3 > 0)
    {
        write_bit(coder, 1);
        coder->scale3--;
    }
    
    for(int8_t i = PRECISION - 2; i >= 0; i--) {
        write_bit(coder, coder->low >> i);
    }

    // Flush any remaining bits in the buffer
    if (coder->bit_count > 0) {
        coder->bit_buffer <<= (8 - coder->bit_count);
        fputc(coder->bit_buffer, stdout);
    }

    uint64_t max_c1, max_c2, max_c3;
    get_max_context(coder->n_symbols, coder->context, &max_c1, &max_c2, &max_c3);
    free_freq(max_c1, max_c2, max_c3, &coder->freq);
}

/**
 * DECODER FUNCTIONS
 */
uint8_t read_bit(ArithmeticCoder *coder) {
    if ((coder->bits_count & 7) == 0) {
        int byte = fgetc(stdin);
        if (byte == EOF) byte = 0;
        coder->input_byte = (uint8_t)byte;
    }
    uint8_t bit = (coder->input_byte >> 7) & 1;
    coder->input_byte <<= 1;
    coder->bits_count++;
    return bit;
}

int init_decoder(ArithmeticCoder *coder, int n_symbols, int context, int context_window, int update_periode, int softening, int ponderation) {
    coder->n_symbols = n_symbols;
    coder->context = context;
    coder->context_window = context_window;
    coder->update_periode = update_periode;
    coder->softening = softening;
    coder->ponderation = ponderation;

    coder->low = 0;
    coder->high = TOP_VALUE;
    coder->word_buffer = 0;
    coder->bits_count = 0;

    uint64_t max_c1, max_c2, max_c3;

    get_max_context(coder->n_symbols, context, &max_c1, &max_c2, &max_c3);

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->freq) != 0) {
        return -1;
    }

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->freq_window) != 0) {
        return -1;
    }

    if (initialize_freq(max_c1, max_c2, max_c3, coder->n_symbols, &coder->simple_freq) != 0) {
        return -1;
    }
    
    for (int c1 = 0; c1 < max_c1; c1++) {
    for (int c2 = 0; c2 < max_c2; c2++) {
    for (int c3 = 0; c3 < max_c3; c3++) {
        for (int i = 0; i <= n_symbols; i++) {
            coder->simple_freq[c1][c2][c3][i] = coder->softening;
            coder->freq[c1][c2][c3][i] = i * coder->softening;
            coder->freq_window[c1][c2][c3][i] = 0;
        }
    }
    }
    }

    for (int i = 0; i < PRECISION; i++) {
        coder->word_buffer = (coder->word_buffer << 1) | read_bit(coder);
    }

    return 0;

}

uint16_t decode_symbol(ArithmeticCoder *coder, uint64_t c1, uint64_t c2, uint64_t c3) {
    uint64_t range = coder->high - coder->low + 1;

    uint32_t position = (uint32_t)((((uint64_t)(coder->word_buffer - coder->low + 1) * coder->freq[c1][c2][c3][coder->n_symbols]) - 1) / range);

    // Binary Search
    uint32_t left = 0, right = coder->n_symbols, mid;
    while (left < right) {
        mid = left + (right - left) / 2;
        if (coder->freq[c1][c2][c3][mid + 1] <= position) {
            left = mid + 1;
        } else {
            right = mid;
        }
    }
    uint16_t symbol = (uint16_t)left;

    coder->high = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][symbol + 1]) / coder->freq[c1][c2][c3][coder->n_symbols]) - 1);
    coder->low  = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[c1][c2][c3][symbol]) / coder->freq[c1][c2][c3][coder->n_symbols]));

    while (((coder->low ^ coder->high) & HALF) == 0)  {
        coder->word_buffer = ((coder->word_buffer << 1) & TOP_VALUE) | read_bit(coder);
        coder->low = (coder->low << 1) & TOP_VALUE;
        coder->high = ((coder->high << 1) & TOP_VALUE) | 1;
    }
    
    // E3 condition
    while ((coder->low >> (PRECISION - 2) & 1 ) && !((coder->high >> (PRECISION - 2)) & 1)) {
        coder->low = (coder->low & (1 << (PRECISION - 1))) | ((coder->low & (TOP_VALUE >> 2)) << 1);
        coder->high = (coder->high & (1 << (PRECISION - 1))) | ((coder->high & (TOP_VALUE >> 2)) << 1) | 1;

        coder->word_buffer = (((coder->word_buffer << 1) & TOP_VALUE) | read_bit(coder)) ^ (1 << (PRECISION - 1));

    }

    return symbol;
}

void finalize_decoding(ArithmeticCoder *coder) {
    uint64_t max_c1, max_c2, max_c3;
    get_max_context(coder->n_symbols, coder->context, &max_c1, &max_c2, &max_c3);
    free_freq(max_c1, max_c2, max_c3, &coder->freq);
}


int main(int argc, char *argv[]) {
    if (argc != 7) {
        fprintf(stderr, "Usage: %s\n <n_words> <context> <context-window> <update-freq> <softening> <ponderation>", argv[0]);
        return 1;
    }
    
    // Obtener el número de palabras
    int words = atoi(argv[1]);

    // Obtener el contexto como string
    char *context_str = argv[2];

    // Convertir el contexto a una lista de enteros
    int context[16];
    int context_size = 0;
    
    char *token = strtok(context_str, ",");
    while (token != NULL && context_size < 16) {
        context[context_size++] = atoi(token);
        token = strtok(NULL, ",");
    }

    // Obtener la ventana de contexto
    int context_window = atoi(argv[3]);

    int update_periode = atoi(argv[4]);
    
    int softening = atoi(argv[5]);

    int ponderation = atoi(argv[6]);

    Header header;
    if (header_parse_stdin(&header) != 0) return 1;
    header.data = header.state == COMPRESS ? BITSTREAM : RESIDUAL;
    print_header(&header);

    DataPacket inputData = {0}; 

    uint8_t bp = 0;
    uint8_t it = 0;

    while (body_parse_stdin(&inputData) == 0) {
        DataPacket outputBody = {0};
        outputBody.id = 0;
        outputBody.type = DATA_TYPE_BITSTREAM;
        outputBody.bits = inputData.bits;

        ArithmeticCoder coder;  
        if (header.state == COMPRESS) {
            if ((inputData.type != DATA_TYPE_IMAGE) && (inputData.type != DATA_TYPE_RESIDUALS)) {
                continue; // Implement a forward data
            }    
            init_coder(&coder, inputData.bits == 0 ? words : 1 << inputData.bits, context[it % context_size], context_window, update_periode, softening, ponderation);

            outputBody.type = DATA_TYPE_BITSTREAM;
            start_body(&outputBody, stdout);
    
            uint64_t c1, c2, c3;
    
            uint64_t ***imageData = NULL;

            if (get_image_from_stdin(&inputData, header, &imageData) != 0) {
                printf("Error generating image\n");
                return 1;
            }

            double efficiency = 0;
            for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                    for (uint64_t x = 0; x < header.x; x++) {
                        get_context(coder.context, coder.n_symbols, imageData, z, y, x, header.x -1, &c1, &c2, &c3);
                        uint32_t px = coder.freq[c1][c2][c3][imageData[z][y][x] + 1] - coder.freq[c1][c2][c3][imageData[z][y][x]];
                        uint64_t tot = coder.freq[c1][c2][c3][1 << inputData.bits];
                        
                        efficiency += log2(((float)tot/px));

                        if (encode_symbol(&coder, imageData[z][y][x], c1, c2, c3) != 0) {
                            fprintf(stderr, "Error in encode symbol\n");
                            return -1;
                        }

                        update_freq(&coder, imageData[z][y][x], c1, c2, c3);

                    }
                }
            }


            fprintf(stderr, "%d-%f\n",bp, efficiency / (header.z*header.y*header.x));
            bp += inputData.bits;

            finalize_encoding(&coder);
            end_body(&outputBody, stdout);
            free_image(imageData, header);
    
        } else {
            if (inputData.type != DATA_TYPE_BITSTREAM) {
                continue; // Implement a forward data
            }

            init_decoder(&coder, inputData.bits == 0 ? words : 1 << inputData.bits, context[it % context_size], context_window, update_periode, softening, ponderation);
            uint64_t c1, c2, c3;
    
            uint64_t ***outputData = NULL;
            initialize_image_matrix(header.z, header.y, header.x, &outputData);
            
            outputBody.type = DATA_TYPE_IMAGE;
            start_body(&outputBody, stdout);
    
            for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                    for (uint64_t x = 0; x < header.x; x++) {
                        get_context(coder.context, coder.n_symbols, outputData, z, y, x, header.x - 1, &c1, &c2, &c3);
    
                        uint16_t symbol = decode_symbol(&coder, c1, c2, c3);

                        outputData[z][y][x] = symbol;
                        
                        update_freq(&coder, symbol, c1, c2, c3);

                        if (inputData.bits <= 8) {
                            fputc(symbol, stdout);   
                        } else {

                            fwrite(&symbol, sizeof(uint16_t), 1, stdout);
                        }
                    }
                }
            }
            bp += inputData.bits;
            finalize_decoding(&coder);
            end_body(&outputBody, stdout);
            free_image(outputData, header);
        }
        it++;
    }

    return 0;
}
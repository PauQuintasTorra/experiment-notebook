#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>

#define RAW 0
#define RESIDUAL 1
#define BITSTREAM 2

#define COMPRESS 0
#define DECOMPRESS 1 

typedef struct {
    char signed_char;
    int bits;
    char endian;
    int z, x, y;
    int data;
    int state;
} Header;

// Función para extraer el header desde el nombre del archivo
int header_parse_filename(const char *filename, Header *header);

// Función para extraer el header desde el buffer
int header_parse_stdin(Header *header);

// Función para imprimir el header en un formato estructurado
void print_header(const Header *header);

void store_header(const Header *header, FILE *file);
#endif

#ifndef DATA_H
#define DATA_H

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

typedef enum {
    DATA_TYPE_IMAGE,
    DATA_TYPE_BITSTREAM,
    DATA_TYPE_RESIDUALS
} DataType;

typedef struct DataPacket {
    DataType type;
    int id;
    char buffer[1024];
    size_t pointer;
    size_t bytes_read;
    uint8_t bits;
    char endian;
    int end_data;
    size_t end_pos;
} DataPacket;

int body_parse_stdin(DataPacket *packet);

int body_fegtc(DataPacket *packet, FILE *stream);
size_t body_fread(DataPacket *packet, void *ptr, size_t size, size_t count, FILE *stream);

void start_body(DataPacket *packet, FILE *file);
void end_body(DataPacket *packet, FILE *file);

#endif
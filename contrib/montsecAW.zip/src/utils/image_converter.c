#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "image_converter.h"

int initialize_image_matrix(int z, int y, int x, uint64_t ****matrix) {
    *matrix = (uint64_t ***)malloc(z * sizeof(uint64_t **));  // Asignamos la memoria para la matriz 3D
    if (!*matrix) return 1;

    for (int i = 0; i < z; i++) {
        (*matrix)[i] = (uint64_t **)malloc(y * sizeof(uint64_t *));  // Asignamos la memoria para cada capa
        if (!(*matrix)[i]) {
            for (int j = 0; j < i; j++) {
                free((*matrix)[j]);
            }
            free(*matrix);
            return 1;
        }
        for (int j = 0; j < y; j++) {
            (*matrix)[i][j] = (uint64_t *)calloc(x, sizeof(uint64_t));  // Asignamos la memoria para cada fila
            if (!(*matrix)[i][j]) {
                for (int k = 0; k < j; k++) {
                    free((*matrix)[i][k]);
                }
                free((*matrix)[i]);
                for (int k = 0; k < i; k++) {
                    free((*matrix)[k]);
                }
                free(*matrix);
                return 1;
            }
        }
    }
    return 0;
}

int get_image_from_stdin(DataPacket *packet, const Header header, uint64_t ****matrix) {
    uint8_t buffer[BUFFER_SIZE]; 
    size_t bytes_read;

    // Inicializa la matriz correctamente
    if (initialize_image_matrix(header.z, header.y, header.x, matrix) != 0) {
        printf("Error initializing the matrix\n");
        return 1;
    }

    int z_index = 0, y_index = 0, x_index = 0;
    uint16_t result;

    // Manejo de los datos de la imagen
    while ((bytes_read = body_fread(packet, buffer, 1, sizeof(buffer), stdin)) > 0) {
        for (size_t i = 0; i < bytes_read;) {
            if (packet->bits > 8) {
                if (packet->endian == 'b') {
                    result = (uint16_t)(buffer[i + 1] | (buffer[i] << 8));
                }
                else {
                    result = (uint16_t)(buffer[i] | (buffer[i + 1] << 8));
                }

                (*matrix)[z_index][y_index][x_index] = (uint64_t)result;
                i += 2;
            } else {
                (*matrix)[z_index][y_index][x_index] = (uint64_t)buffer[i];
                i++;
            }

            // Avanzar en las posiciones del tensor
            x_index++;
            if (x_index >= header.x) {
                x_index = 0;
                y_index++;
            }

            if (y_index >= header.y) {
                y_index = 0;
                z_index++;
            }

            if (z_index >= header.z) {
                break;
            }
        }

    }

    if (z_index < header.z - 1) {
        printf("Error filling the matrix\n");
        return 1;  // Error: no se completó el llenado de la matriz
    }

    return 0;  // Éxito
}


void free_image(uint64_t ***matrix, Header header) {
    if (matrix == NULL) return;

    for (int i = 0; i < header.z; i++) {
        if (matrix[i] == NULL) continue;

        for (int j = 0; j < header.y; j++) {
            if (matrix[i][j] != NULL) {
                free(matrix[i][j]);
            }
        }

        free(matrix[i]);
    }
    free(matrix);
    matrix = NULL;
}
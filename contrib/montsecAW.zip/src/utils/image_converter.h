#ifndef IMAGE_CONVERTER_H
#define IMAGE_CONVERTER_H

#include "header.h"
#include "body.h"

#define BUFFER_SIZE 1024

int initialize_image_matrix(int z, int y, int x, uint64_t ****matrix);

// Función para leer la imagen desde la entrada estándar y llenar la matriz 3D
int get_image_from_stdin(DataPacket *packet, const Header header, uint64_t ****matrix);

// Función para liberar la memoria de la matriz 3D
void free_image(uint64_t ***matrix, Header header);

#endif

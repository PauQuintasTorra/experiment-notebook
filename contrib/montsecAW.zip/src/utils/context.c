#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include "context.h"

double PWeights[6] = { 1.0 / 6, 1.0 / 6, 1.0 / 6, 1.0 / 6, 1.0 / 6, 1.0 / 6};

double PWeights2[18] = { 1.0 / 21, 1.0 / 21, 1.0 / 21, 1.0 / 21, 0.0 / 21,
                         1.0 / 21, 1.0 / 21, 1.0 / 21, 1.0 / 21, 0.0 / 21, 
                         1.0 / 21, 1.0 / 21, 1.0 / 21, 2.0 / 21, 2.0 / 21, 
                         1.0 / 21, 2.0 / 21, 3.0 / 21
                      };

double PWeights3[23] = { 1.0 / 25, 1.0 / 25, 1.0 / 25, 1.0 / 25, 0.0 / 25,
                         1.0 / 25, 1.0 / 25, 1.0 / 25, 1.0 / 25, 0.0 / 25,
                         1.0 / 25, 1.0 / 25, 1.0 / 25, 1.0 / 25, 0.0 / 25, 
                         1.0 / 25, 1.0 / 25, 1.0 / 25, 2.0 / 25, 2.0 / 25, 
                         1.0 / 25, 2.0 / 25, 3.0 / 25
                      };

double PMemory = 0;

void get_context(int context, int n_symbols, uint64_t ***image, uint64_t z, uint64_t y, uint64_t x, uint64_t max_x, uint64_t *c1, uint64_t *c2, uint64_t *c3) {

    if (context == NO_CONTEXT || (y == 0 & x == 0)) {
        *c1 = 0;
        *c2 = 0;
        *c3 = 0;
    } 
    else if (context == CONTEXT_UP) {
        *c1 = 0;
        *c2 = 0;
        *c3 = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
    }
    else if (context == CONTEXT_LEFT) {
        *c1 = 0;
        *c2 = 0;
        *c3 = x == 0 ? image[z][y-1][x] : image[z][y][x-1];
    }
    else if (context == CONTEXT_UP_LEFT ) {
        *c1 = 0;
        *c2 = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
        *c3 = x == 0 ? image[z][y-1][x] : image[z][y][x-1];
    }
    else if (context == CONTEXT_UP_LEFT_DIAGONAL) {
        *c1 = (x == 0 || y == 0) ? 0 : image[z][y-1][x-1];
        *c2 = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
        *c3 = x == 0 ? image[z][y-1][x] : image[z][y][x-1];
    }
    else if (context == CONTEXT_UP_LEFT_SORTED) {
        *c1 = 0;
        *c2 = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
        *c3 = x == 0 ? image[z][y-1][x] : image[z][y][x-1];
        if (*c2 > *c3) {
            uint8_t aux = *c2;
            *c2 = *c3;
            *c3 = aux;
        }

    }
    else if (context == CONTEXT_UP_LEFT_MIXED) {
        uint32_t mixed = y == 0 ? image[z][y][x-1] : image[z][y-1][x];
        mixed += x == 0 ? image[z][y-1][x] : image[z][y][x-1];
        *c1 = 0;
        *c2 = 0;
        *c3 = mixed;
    }
    else if (context == CONTEXT_UP_LEFT_DIAGONAL_MIXED) {
        uint32_t mixed = y == 0 && x > 0 ? image[z][y][x-1] * 3 : 0;
        mixed += y > 0 && x == 0 ? image[z][y-1][x] * 3 : 0;
        mixed += y > 0 && x > 0 ? image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] : 0;
        *c1 = 0;
        *c2 = 0;
        *c3 = mixed;
    }
    else if (context == CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {
        uint32_t mixed = y == 0 && x > 0 ? image[z][y][x-1] * 4 : 0;
        mixed += y > 0 && x == 0 ? image[z][y-1][x] * 4 : 0;
        mixed += y > 0 && x > 0 && x == max_x ? image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] : 0;
        mixed += y > 0 && x > 0 && x < max_x ? image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1] : 0;

        *c1 = 0;
        *c2 = 0;
        *c3 = mixed;
    }
    else if (context == CONTEXT_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 5;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 5;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] + image[z][y-1][x-1];
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1];
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        }

        *c1 = 0;
        *c2 = 0;
    }
    else if (context == CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_WEIGHTED_MIXED) {
        uint32_t mixed = y == 0 && x > 0 ? image[z][y][x-1] * 5 : 0;
        mixed += y > 0 && x == 0 ? image[z][y-1][x] * 5 : 0;
        mixed += y > 0 && x > 0 && x == max_x ? image[z][y-1][x] * 3 + image[z][y][x-1] + image[z][y-1][x-1] : 0;
        mixed += y > 0 && x > 0 && x < max_x ? image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1] : 0;

        *c1 = 0;
        *c2 = 0;
        *c3 = mixed;
    }
    else if (context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 6;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 6;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] * 2+ image[z][y-1][x-1];
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] * 2 + image[z][y-1][x-1];
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        }

        if (y > 1 && x > 1 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y][x-2] + image[z][y-1][x-1] + image[z][y-1][x+1];
        }

        *c1 = 0;
        *c2 = 0;
    }
    else if (context == CONTEXT_ALL_TWO) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 10;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 10;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 4 + image[z][y][x-1] * 4+ image[z][y-1][x-1] * 2;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] * 3 + image[z][y-1][x-1] * 2 + image[z][y-1][x+1] * 2;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] * 2 + image[z][y-1][x] * 3 + image[z][y][x-1] * 3 + image[z][y-1][x-1] * 2;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 3 + image[z][y][x-1] * 2 + image[z][y-1][x-1] * 2 + image[z][y-1][x+1] * 2;
        }

        if (y > 1 && x > 1 && x < max_x) {
            *c3 = image[z][y-2][x-2] + image[z][y-2][x-1] + image[z][y-2][x] + image[z][y-2][x+1] + image[z][y-1][x-2] + image[z][y-1][x-1] + image[z][y-1][x] + image[z][y-1][x+1] + image[z][y][x-2] + image[z][y][x-1];
        }

        *c1 = 0;
        *c2 = 0;
    }
    else if (context == CONTEXT_UP_LEFT_POWER) {
        uint64_t mixed = y == 0 ? image[z][y][x-1] * image[z][y][x-1] : image[z][y-1][x] * image[z][y-1][x];
        mixed += x == 0 ? image[z][y-1][x] * image[z][y-1][x] : image[z][y][x-1] * image[z][y][x-1];
        *c1 = 0;
        *c2 = 0;
        *c3 = (uint64_t)round(sqrt((double)mixed));
    }  else if (context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED_POWER) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 6;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 6;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] * 2+ image[z][y-1][x-1];
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 3 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] * 2 + image[z][y-1][x-1];
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] + image[z][y-1][x] * 2 + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1];
        }

        if (y > 1 && x > 1 && x < max_x) {
            uint64_t mixed = image[z][y-2][x] * image[z][y-2][x] + image[z][y-1][x] * image[z][y-1][x] + image[z][y][x-1] * image[z][y][x-1] +
            image[z][y][x-2] * image[z][y][x-2] + image[z][y-1][x-1] * image[z][y-1][x-1] + image[z][y-1][x+1] * image[z][y-1][x+1];
            *c3 = (uint64_t)round(sqrt((double)mixed));
        }

        *c1 = 0;
        *c2 = 0;
    } else if (context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_REGRESSION) {
        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 3;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 4;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 4;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 5;
        }

        if (y > 1 && x > 1 && x < max_x) {
            if (x > 2) {
                double update_weight = (image[z][y][x-1] - PMemory) * 3E-8;
                PWeights[0] += update_weight * image[z][y-2][x-1];
                PWeights[1] += update_weight * image[z][y-1][x-1];
                PWeights[2] += update_weight * image[z][y][x-2];
                PWeights[3] += update_weight * image[z][y][x-3];
                PWeights[4] += update_weight * image[z][y-1][x-2];
                PWeights[5] += update_weight * image[z][y-1][x];

            }

            PMemory = image[z][y-2][x] * PWeights[0] + image[z][y-1][x] * PWeights[1] + image[z][y][x-1] * PWeights[2] + image[z][y][x-2] * PWeights[3] + image[z][y-1][x-1] * PWeights[4] + image[z][y-1][x+1] * PWeights[5];
           // *c3 = image[z][y-2][x] * (int)round(PWeights[0] * 6) + image[z][y-1][x] * (int)round(PWeights[1] * 6) + image[z][y][x-1] * (int)round(PWeights[2] * 6) + image[z][y][x-2] * (int)round(PWeights[3] * 6) + image[z][y-1][x-1] * (int)round(PWeights[4] * 6) + image[z][y-1][x+1] * (int)round(PWeights[5] * 6);
            //*c3 = (int)round((6.0 * (float)*c3) / ((int)round(PWeights[0] * 6) + (int)round(PWeights[1] * 6) + (int)round(PWeights[2] * 6) + (int)round(PWeights[3] * 6) + (int)round(PWeights[4] * 6) + (int)round(PWeights[5] * 6)));
            *c3 = (int)round(PMemory);
            if (*c3 > n_symbols - 1) {
                *c3 = n_symbols - 1;
            } else if(*c3 < 0) {
                *c3 = 0;
            }
            
        }

        *c1 = 0;
        *c2 = 0;
    }  else if (context == CONTEXT_ALL_REGRESSION) {
        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 3;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 4;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 4;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 5;
        }

        if (y > 3 && x > 3 && x < max_x) {
            if (x > 4) {
                double update_weight = (image[z][y][x-1] - PMemory) * 3E-8;
                for (int i = 0; i < 18; i++) {
                    PWeights2[i] += update_weight * image[z][y - 3 + (i / 5)][x - 4 + (i % 5)];
                }
            }
            PMemory = 0;

            for (int i = 0; i < 18; i++) {
                PMemory += image[z][y - 3 + (i / 5)][x - 3 + (i % 5)] * PWeights2[i];
            }
            *c3 = (uint64_t)round(PMemory);

            if (*c3 > n_symbols - 1) {
                *c3 = n_symbols - 1;
            } else if(*c3 < 0) {
                *c3 = 0;
            }
            
        }

        *c1 = 0;
        *c2 = 0;
    }  else if (context == CONTEXT_PREDICTOR) {
        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 3;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 4;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 4;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 5;
        }

        if (y > 3 && x > 3 && x < max_x) {
            *c3 = (image[z][y][x-1] * 3 + image[z][y][x-2] * 2 + image[z][y][x-3] + image[z][y-1][x+1] * 2 + 
                  image[z][y-1][x] * 2 + image[z][y-1][x-1] + image[z][y-1][x-2] + image[z][y-1][x-3] + 
                  image[z][y-2][x] + image[z][y-2][x-1] + image[z][y-2][x-2] + image[z][y-2][x-3] +
                  image[z][y-3][x] + image[z][y-3][x-1] + image[z][y-3][x-2] + image[z][y-3][x-3]) / 21;
            
        }


        *c1 = 0;
        *c2 = 0;
    }else if (context == CONTEXT_ALL_REGRESSION_MORE) {
        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 3;
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 4;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1]) / 4;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = (image[z][y-2][x] + image[z][y-1][x] + image[z][y][x-1] + image[z][y-1][x-1] + image[z][y-1][x+1]) / 5;
        }

        if (y > 4 && x > 3 && x < max_x) {
            if (x > 4) {
                double update_weight = (image[z][y][x-1] - PMemory) * 3E-8;
                for (int i = 0; i < 23; i++) {
                    PWeights3[i] += update_weight * image[z][y - 4 + (i / 5)][x - 4 + (i % 5)];
                }
            }
            PMemory = 0;

            for (int i = 0; i < 23; i++) {
                PMemory += image[z][y - 4 + (i / 5)][x - 3 + (i % 5)] * PWeights3[i];
            }
            *c3 = (uint64_t)round(PMemory);

            if (*c3 > n_symbols - 1) {
                *c3 = n_symbols - 1;
            } else if(*c3 < 0) {
                *c3 = 0;
            }
            
        }

        *c1 = 0;
        *c2 = 0;
    } else if (context == CONTEXT_MAX) {
        *c3 = 0;
         if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1];
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x];
        } else if (y > 0 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x];
        } else if (y > 0 && x > 0) {
            *c3 = image[z][y][x-1];
            *c3 = *c3 > image[z][y-1][x] ? *c3 : image[z][y-1][x];
            *c3 = *c3 > image[z][y-1][x-1] ? *c3 : image[z][y-1][x-1];
            *c3 = *c3 > image[z][y-1][x+1] ? *c3 : image[z][y-1][x+1];
        }

        *c3 = *c3;
        *c2 = 0;
        *c1 = 0;
    }
    else if (context == CONTEXT_EXTREME_MIXED) {

        if (y == 0 && x > 0) {
            *c3 = image[z][y][x-1] * 21;
        } else if (y > 0 && x == 0) {
            *c3 = image[z][y-1][x] * 21;
        } else if (y == 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-1][x] * 10 + image[z][y][x-1] * 10 + image[z][y-1][x-1];
        } else if (y == 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-1][x] * 10 + image[z][y][x-1] * 6 + image[z][y-1][x-1] * 3 + image[z][y-1][x+1] * 2;
        } else if (y > 1 && x > 0 && x == max_x) {
            *c3 = image[z][y-2][x] * 3 + image[z][y-1][x] * 8 + image[z][y][x-1] * 8 + image[z][y-1][x-1] * 2;
        } else if (y > 1 && x > 0 && x < max_x) {
            *c3 = image[z][y-2][x] * 3 + image[z][y-1][x] * 8 + image[z][y][x-1] * 6 + image[z][y-1][x-1] * 2 + image[z][y-1][x+1] * 2;
        }

        if (y > 1 && x > 1 && x < max_x) {
            *c3 = image[z][y-2][x-2] * 2 + image[z][y-2][x-1] * 2 + image[z][y-2][x] * 2 + image[z][y-2][x+1] * 2 +
                  image[z][y-1][x-2] * 2 + image[z][y-1][x-1] * 2 + image[z][y-1][x] * 2 + image[z][y-2][x+1] * 2 + 
                  image[z][y-0][x-2] * 2 + image[z][y-0][x-1] * 3; // CONTEXT PIXEL;
        }

        if (y > 2 && x > 2 && x < max_x - 1) {
            *c3 = image[z][y-3][x-3] + image[z][y-3][x-2] + image[z][y-3][x-1] + image[z][y-3][x] + image[z][y-3][x+1] + image[z][y-3][x+2] +
                  image[z][y-2][x-3] + image[z][y-2][x-2] + image[z][y-2][x-1] + image[z][y-2][x] + image[z][y-2][x+1] + image[z][y-2][x+2] +
                  image[z][y-1][x-3] + image[z][y-1][x-2] + image[z][y-1][x-1] + image[z][y-1][x] + image[z][y-2][x+1] + image[z][y-2][x+2] + 
                  image[z][y-0][x-3] + image[z][y-0][x-2] + image[z][y-0][x-1]; // CONTEXT PIXEL;
        }
 
        *c1 = 0;
        *c2 = 0;
    }

}

void get_max_context(int n_symbols, int context, uint64_t *max_c1, uint64_t *max_c2, uint64_t *max_c3) {
    if (context == NO_CONTEXT) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = 1;
    } else if (context == CONTEXT_LEFT || context == CONTEXT_UP) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols;
    } else if (context == CONTEXT_UP_LEFT) {
        *max_c1 = 1;
        *max_c2 = n_symbols;
        *max_c3 = n_symbols;
    } else if (context == CONTEXT_UP_LEFT_MIXED){
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 2;
    } else if (context == CONTEXT_UP_LEFT_SORTED){
        *max_c1 = 1;
        *max_c2 = n_symbols;
        *max_c3 = n_symbols;
    } else if (context == CONTEXT_UP_LEFT_DIAGONAL) {
        *max_c1 = n_symbols;
        *max_c2 = n_symbols;
        *max_c3 = n_symbols;
    } else if (context == CONTEXT_UP_LEFT_DIAGONAL_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 3;
    } else if (context == CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 4;
    } else if (context == CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_WEIGHTED_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 5;
    } else if (context == CONTEXT_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 5;
    } else if (context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 6;
    } else if (context == CONTEXT_ALL_TWO) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 10;
    } else if (context == CONTEXT_UP_LEFT_POWER){
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 2;
    }else if (context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED_POWER) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 6;
    } else if(context == CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_REGRESSION) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols;
    } else if (context == CONTEXT_ALL_REGRESSION) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols;
    } else if (context == CONTEXT_PREDICTOR) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols;
    }  else if (context == CONTEXT_ALL_REGRESSION_MORE) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols;
    } else if (context == CONTEXT_MAX) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols;
    } else if (context == CONTEXT_EXTREME_MIXED) {
        *max_c1 = 1;
        *max_c2 = 1;
        *max_c3 = n_symbols * 21;
    }
}
#include <stdio.h>
#include <math.h>

#define TABLE_SIZE 1000000
#define FILE_NAME "entropy_table.bin"

double probability[TABLE_SIZE];
double entropy_table[TABLE_SIZE];

void precompute_entropy_table() {
    for (int i = 1; i < TABLE_SIZE; i++) {
        double p = (double)i / TABLE_SIZE;
        probability[i] = p;
        entropy_table[i] = -p * log2(p);
    }
    probability[0] = 0.0;
    entropy_table[0] = 0.0;
}

void save_to_binary(const char *filename) {
    FILE *file = fopen(filename, "wb");
    if (!file) {
        perror("Error opening file");
        return;
    }

    fwrite(probability, sizeof(double), TABLE_SIZE, file);
    fwrite(entropy_table, sizeof(double), TABLE_SIZE, file);
    fclose(file);
    printf("Entropy table saved to %s (binary format)\n", filename);
}

int main() {
    precompute_entropy_table();
    save_to_binary(FILE_NAME);
    return 0;
}

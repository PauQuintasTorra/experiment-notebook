#include "body.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//DELME
#include <ctype.h>


int body_parse_stdin(DataPacket *packet) {
    char line[256];

    packet->pointer = 0;
    packet->end_data = 0;
    packet->end_pos = 0;
    packet->bytes_read = 0;

    while (fgets(line, sizeof(line), stdin)) {
        line[strcspn(line, "\n")] = 0;  

        /*if (strstr(line, "[END DATA]") != NULL) {
            fprintf(stderr, "END DATA\n");
            return -1;  // Unexpected end of data
        }*/

        if (strstr(line, "[CONTENT]") != NULL) {
            return 0;
        }

        if (strstr(line, "id:") != NULL) {
            sscanf(line, "id: %d", &packet->id);
        } else if (strstr(line, "type:") != NULL) {
            sscanf(line, "type: %d", &packet->type);
        } else if (strstr(line, "bits:") != NULL) {
            sscanf(line, "bits: %hhu", &packet->bits);
        } else if (strstr(line, "endian:") != NULL) {
            sscanf(line, "endian: %c", &packet->endian);
        }
    }
    return -1;
}

int body_fegtc(DataPacket *packet, FILE *stream) {
    if (packet->end_data && packet->pointer >= packet->end_pos) return EOF;

    if (packet->pointer == packet->bytes_read) {

        size_t preserve = (packet->bytes_read < 12) ? packet->bytes_read : 12;
        memmove(packet->buffer, packet->buffer + packet->bytes_read - preserve, preserve);
        
        size_t bytes_new = fread(packet->buffer + preserve, 1, sizeof(packet->buffer) - preserve, stream);

        packet->bytes_read = bytes_new + preserve;

        packet->pointer = preserve;

        if (bytes_new == 0) {
            packet->end_data = 1;
            packet->end_pos = packet->pointer;
            return EOF;
        }
        
        char *pos = memmem(packet->buffer, packet->bytes_read,  "\n[END DATA]\n", 12);
        if (pos != NULL) {
            packet->end_pos = pos - packet->buffer;
            packet->end_data = 1;
            
            for (size_t i = packet->bytes_read; i > packet->end_pos + 12; i--) {
                ungetc((unsigned char)packet->buffer[i - 1], stream);
            }
            packet->bytes_read = packet->end_pos;
        }
    }

    return (packet->pointer < packet->bytes_read) ? (unsigned char) packet->buffer[packet->pointer++] : EOF;
}


size_t body_fread(DataPacket *packet, void *ptr, size_t size, size_t count, FILE *stream) {
    size_t total_read = 0;
    char *char_ptr = (char *)ptr;

    for (size_t i = 0; i < size * count; i++) {
        int c = body_fegtc(packet, stream);
        if (c == EOF) break;
        char_ptr[i] = (char)c;
        total_read++;
    }

    return total_read / size;
}

void start_body(DataPacket *packet, FILE *file) {
    fprintf(file, "[DATA]\n"
                  "type: %d\n"
                  "id: %d\n",
            packet->type, packet->id);

    if (packet->bits != 0) {
        fprintf(file, "bits: %hhu\n", packet->bits);
    }

    if (packet->endian == 'l' || packet->endian == 'b') {
        fprintf(file, "endian: %c\n", packet->endian);
    }

    fprintf(file, "[CONTENT]\n");
}

void end_body(DataPacket *packet, FILE *file) {
    fprintf(file,"\n[END DATA]\n");
}

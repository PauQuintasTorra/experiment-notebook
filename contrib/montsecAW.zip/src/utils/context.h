#include <stdint.h>
#ifndef CONTEXT_H
#define CONTEXT_H

typedef enum {
    NO_CONTEXT,
    CONTEXT_LEFT,
    CONTEXT_UP,
    CONTEXT_UP_LEFT,
    CONTEXT_UP_LEFT_DIAGONAL,
    CONTEXT_UP_LEFT_MIXED,
    CONTEXT_UP_LEFT_SORTED,
    CONTEXT_UP_LEFT_DIAGONAL_MIXED,
    CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED,
    CONTEXT_UP_LEFT_DIAGONAL_ANTIDIAGONAL_WEIGHTED_MIXED,
    CONTEXT_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED,
    CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED,
    CONTEXT_ALL_TWO,
    CONTEXT_UP_LEFT_POWER,
    CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_MIXED_POWER,
    CONTEXT_UP_UP_LEFT_LEFT_DIAGONAL_ANTIDIAGONAL_REGRESSION,
    CONTEXT_ALL_REGRESSION,
    CONTEXT_PREDICTOR, 
    CONTEXT_ALL_REGRESSION_MORE,
    CONTEXT_MAX,
    CONTEXT_EXTREME_MIXED
} ContextType;

extern double PWeights[6];
extern double PWeights2[18];
extern double PMemory;

void get_context(int context, int n_symbols, uint64_t ***image, uint64_t z, uint64_t y, uint64_t x, uint64_t max_x, uint64_t *c1, uint64_t *c2, uint64_t *c3);
void get_max_context(int n_symbols, int context, uint64_t *max_c1, uint64_t *max_c2, uint64_t *max_c3);

#endif
#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int header_parse_filename(const char *filename, Header *header) {
    char format[50];
    char *last_part = strrchr(filename, '_');
    if (last_part != NULL) {
        sscanf(last_part + 1, "%s", format);
    } else {
        fprintf(stderr, "Error: Invalid filename format.\n");
        return 1;
    }

    if (sscanf(format, "%c%d%ce-%dx%dx%d", &header->signed_char, &header->bits, 
               &header->endian, &header->z, &header->y, &header->x) != 6) {
        fprintf(stderr, "Error: Could not parse filename.\n");
        return 1;
    }
    header->data = RAW;

    return 0;
}

int header_parse_stdin(Header *header) {
    char line[256];

    while (fgets(line, sizeof(line), stdin)) {
        line[strcspn(line, "\n")] = 0;  

        if (strstr(line, "[END HEADER]") != NULL) {
            return 0;  // Fin del header
        }

        // Procesar las líneas que contienen información relevante
        if (strstr(line, "signed:") != NULL) {
            sscanf(line, "signed: %c", &header->signed_char);
        } else if (strstr(line, "bits:") != NULL) {
            sscanf(line, "bits: %d", &header->bits);
        } else if (strstr(line, "endian:") != NULL) {
            sscanf(line, "endian: %c", &header->endian);
        } else if (strstr(line, "z:") != NULL) {
            sscanf(line, "z: %d", &header->z);
        } else if (strstr(line, "x:") != NULL) {
            sscanf(line, "x: %d", &header->x);
        } else if (strstr(line, "y:") != NULL) {
            sscanf(line, "y: %d", &header->y);
        } else if (strstr(line, "bin:") != NULL) {
            sscanf(line, "bin: %d", (int *)&header->data);
        } else if (strstr(line, "state:") != NULL) {
            sscanf(line, "state: %d", (int *)&header->state);
        }
    }

    fprintf(stderr, "Error: '[END HEADER]' not found\n");
    return -1;  // Si no se encuentra '[END HEADER]'
}

void print_header(const Header *header) {
    printf("[HEADER]\n"
           "signed: %c\n"
           "bits: %d\n"
           "endian: %c\n"
           "z: %d\n"
           "x: %d\n"
           "y: %d\n"
           "bin: %d\n"
           "state: %d\n"
           "[END HEADER]\n",
           header->signed_char, header->bits, header->endian,
           header->z, header->x, header->y, header->data, header->state);
}

void store_header(const Header *header, FILE *file) {
    fprintf(file,"[HEADER]\n"
        "signed: %c\n"
        "bits: %d\n"
        "endian: %c\n"
        "z: %d\n"
        "x: %d\n"
        "y: %d\n"
        "bin: %d\n"
        "state: %d\n"
        "[END HEADER]\n",
        header->signed_char, header->bits, header->endian,
        header->z, header->x, header->y, header->data, header->state);
}

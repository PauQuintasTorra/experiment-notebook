#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "utils/header.h"

#define MAX_SYMBOLS 256
#define PRECISION 24

#define TOP_VALUE      ((1 << PRECISION) - 1)
#define HALF           (1 << (PRECISION - 1))

typedef struct {
    uint32_t n_symbols;
    uint32_t low, high;
    uint64_t scale3;
    uint32_t freq[MAX_SYMBOLS + 1];

    // Encoder buffers
    uint8_t bit_buffer;
    uint64_t bit_count;
    
    // Decoder state
    uint32_t word_buffer;
    uint8_t input_byte;
    uint64_t bits_count;
} ArithmeticCoder;

/**
 * Global funcitons
 */

void update_freq(ArithmeticCoder *coder, uint8_t symbol) {
    for (int i = symbol + 1; i <= coder->n_symbols; i++) {
        coder->freq[i]++;
    }
}


/**
 * ENCODER FUNCTIONS
 */
static void write_bit(ArithmeticCoder *coder, uint8_t bit) {
    coder->bit_buffer = (coder->bit_buffer << 1) | (bit & 1);
    coder->bit_count++;
    
    // Flush the buffer if it's full
    if (coder->bit_count == 8) {
        fputc(coder->bit_buffer, stdout);
        coder->bit_buffer = 0;
        coder->bit_count = 0;
    }
}

int init_coder(ArithmeticCoder *coder, int n_symbols) {
    coder->n_symbols = n_symbols;
    coder->low = 0;
    coder->high = TOP_VALUE;
    coder->scale3 = 0;
    coder->bit_count = 0;

    for (int i = 0; i <= n_symbols; i++) {
        coder->freq[i] = i;
    }


    return 0;
}

int encode_symbol(ArithmeticCoder *coder, uint8_t symbol) {
    uint64_t range = coder->high - coder->low + 1;
    
    // Calculate new bounds using 64-bit to avoid overflow
    coder->high = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[symbol + 1]) / coder->freq[coder->n_symbols]) - 1);
    coder->low  = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[symbol]) / coder->freq[coder->n_symbols]));

    while (((coder->low ^ coder->high) & HALF) == 0) {
        write_bit(coder, (coder->low >> (PRECISION - 1)) & 1);
        while (coder->scale3 > 0) {
            write_bit(coder, !((coder->low >> (PRECISION - 1)) & 1));
            coder->scale3--;
        }

        coder->low = (coder->low << 1) & TOP_VALUE;
        coder->high = ((coder->high << 1) & TOP_VALUE) | 1;
    } 
    
    // E3 condition
    while ((coder->low >> (PRECISION - 2) & 1 ) && !((coder->high >> (PRECISION - 2)) & 1)) {
        coder->low = (coder->low & (1 << (PRECISION - 1))) | ((coder->low & (TOP_VALUE >> 2)) << 1);
        coder->high = (coder->high & (1 << (PRECISION - 1))) | ((coder->high & (TOP_VALUE >> 2)) << 1) | 1;
        coder->scale3++;
    }

    return 0;
}

void finalize_encoding(ArithmeticCoder *coder) {
    write_bit(coder, (coder->low >> (PRECISION - 1)) & 1);

    while (coder->scale3 > 0)
    {
        write_bit(coder, 1);
        coder->scale3--;
    }
    
    for(uint8_t i = PRECISION - 2; i > 0; i--) {
        write_bit(coder, coder->low >> i);
    }

    // Flush any remaining bits in the buffer
    if (coder->bit_count > 0) {
        coder->bit_buffer <<= (8 - coder->bit_count);
        fputc(coder->bit_buffer, stdout);
    }
}

/**
 * DECODER FUNCTIONS
 */
uint8_t read_bit(ArithmeticCoder *coder) {
    if ((coder->bits_count & 7) == 0) {
        int byte = fgetc(stdin);
        if (byte == EOF) byte = 0;
        coder->input_byte = (uint8_t)byte;
    }
    uint8_t bit = (coder->input_byte >> 7) & 1;
    coder->input_byte <<= 1;
    coder->bits_count++;
    return bit;
}

void init_decoder(ArithmeticCoder *coder, int n_symbols) {
    coder->n_symbols = n_symbols;
    coder->low = 0;
    coder->high = TOP_VALUE;
    coder->word_buffer = 0;
    coder->bits_count = 0;
    for (int i = 0; i <= coder->n_symbols; i++) {
        coder->freq[i] = i;
    }

    for (int i = 0; i < PRECISION; i++) {
        coder->word_buffer = (coder->word_buffer << 1) | read_bit(coder);
    }

}

uint8_t decode_symbol(ArithmeticCoder *coder) {
    uint64_t range = coder->high - coder->low + 1;

    uint32_t position = (uint32_t)((((uint64_t)(coder->word_buffer - coder->low + 1) * coder->freq[coder->n_symbols]) - 1) / range);

    // Binary Search
    uint32_t left = 0, right = coder->n_symbols, mid;
    while (left < right) {
        mid = left + (right - left) / 2;
        if (coder->freq[mid + 1] <= position) {
            left = mid + 1;
        } else {
            right = mid;
        }
    }
    uint8_t symbol = (uint8_t)left;

    coder->high = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[symbol + 1]) / coder->freq[coder->n_symbols]) - 1);
    coder->low  = (uint32_t)(coder->low + ((range * (uint64_t)coder->freq[symbol]) / coder->freq[coder->n_symbols]));

    while (((coder->low ^ coder->high) & HALF) == 0)  {
        coder->word_buffer = ((coder->word_buffer << 1) & TOP_VALUE) | read_bit(coder);
        coder->low = (coder->low << 1) & TOP_VALUE;
        coder->high = ((coder->high << 1) & TOP_VALUE) | 1;
    }
    
    // E3 condition
    while ((coder->low >> (PRECISION - 2) & 1 ) && !((coder->high >> (PRECISION - 2)) & 1)) {
        coder->low = (coder->low & (1 << (PRECISION - 1))) | ((coder->low & (TOP_VALUE >> 2)) << 1);
        coder->high = (coder->high & (1 << (PRECISION - 1))) | ((coder->high & (TOP_VALUE >> 2)) << 1) | 1;

        coder->word_buffer = (((coder->word_buffer << 1) & TOP_VALUE) | read_bit(coder)) ^ (1 << (PRECISION - 1));

    }

    return symbol;
}


int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s\n <n_words>", argv[0]);
        return 1;
    }
    
    // Obtener el número de palabras
    int words = atoi(argv[1]);

    Header header;
    if (header_parse_stdin(&header) != 0) return 1;
    header.data = header.state == COMPRESS ? BITSTREAM : RESIDUAL;
    print_header(&header);

    ArithmeticCoder coder;
    
    if (header.state == COMPRESS) {
        char buffer[1024];
        size_t bytes_read;
        init_coder(&coder, words);

        while ((bytes_read = fread(buffer, 1, sizeof(buffer), stdin)) > 0) {
            for(int i = 0; i < bytes_read; i++) {
                if (encode_symbol(&coder, (uint8_t)buffer[i]) != 0) {
                    fprintf(stderr, "Error in encode symbol\n");
                    return -1;
                }
                update_freq(&coder, (uint8_t)buffer[i]);
            }
        }
        finalize_encoding(&coder);
    } else {
        init_decoder(&coder, words);
        for (size_t i = 0; i < (header.z * header.x * header.y * (header.bits / 8)); i++) {
            uint8_t symbol = decode_symbol(&coder);
            update_freq(&coder, symbol);
            fputc(symbol, stdout);
        }
    }
    return 0;
}
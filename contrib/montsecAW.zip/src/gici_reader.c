#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils/header.h"
#include "utils/body.h"

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <cmp|dec> <input_file>\n", argv[0]);
        return 1;
    }

    char *type = argv[1];
    char *filename = argv[2];

    DataPacket imageData = {0}; 

    if (strcmp(type, "cmp") == 0) {
        Header header;
        if (header_parse_filename(argv[2], &header) != 0) {
            return 1;
        }
        header.state = COMPRESS;
        print_header(&header);


        imageData.id = 0;
        imageData.type = DATA_TYPE_IMAGE;
        imageData.bits = header.bits;
        imageData.endian = header.endian;
        start_body(&imageData,stdout);
    }

    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Error al abrir el archivo");
        return 1;
    }

    char buffer[1024];
    size_t bytes_read;
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) { 
        if (fwrite(buffer, 1, bytes_read, stdout) != bytes_read) {
            perror("Error al escribir en stdout");
            fclose(file);
            exit(EXIT_FAILURE);
        }
    }
    
    if (strcmp(type, "cmp") == 0) {
        end_body(&imageData,stdout);
    }

    fclose(file);

    return EXIT_SUCCESS;
}

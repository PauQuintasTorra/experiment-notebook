#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>

#include "utils/header.h"
#include "utils/body.h"
#include "utils/image_converter.h"
#include "utils/context.h"

#define BUFFER_SIZE 1024
#define NO_EDGE -1

int initialize_freq(uint64_t max_c1, uint64_t max_c2, uint64_t max_c3, uint16_t n_symbols, uint32_t *****freq) {
    *freq = (uint32_t ****)malloc(max_c1 * sizeof(uint32_t ***));

    if (!*freq) return 1;

    for (int i = 0; i < max_c1; i++) {
        (*freq)[i] = (uint32_t ***)malloc(max_c2 * sizeof(uint32_t **));
        if (!(*freq)[i]) {
            for (int j = 0; j < i; j++) {
                free((*freq)[j]);
            }
            free(*freq);
            return 1;
        }

        for (int j = 0; j < max_c2; j++) {
            (*freq)[i][j] = (uint32_t **)malloc(max_c3 * sizeof(uint32_t *));
            if (!(*freq)[i][j]) {
                for (int k = 0; k < j; k++) {
                    free((*freq)[i][k]);
                }
                free((*freq)[i]);
                for (int k = 0; k < i; k++) {
                    free((*freq)[k]);
                }
                free(*freq);
                return 1;
            }

            for (int k = 0; k < max_c3; k++) {
                (*freq)[i][j][k] = (uint32_t *)malloc((n_symbols + 1) * sizeof(uint32_t));
                if (!(*freq)[i][j][k]) {
                    for (int l = 0; l < k; l++) {
                        free((*freq)[i][j][l]);
                    }
                    free((*freq)[i][j]);
                    for (int l = 0; l < j; l++) {
                        for (int m = 0; m < max_c3; m++) {
                            free((*freq)[i][l][m]);
                        }
                        free((*freq)[i][l]);
                    }
                    free((*freq)[i]);
                    for (int l = 0; l < i; l++) {
                        for (int m = 0; m < max_c2; m++) {
                            for (int n = 0; n < max_c3; n++) {
                                free((*freq)[l][m][n]);
                            }
                            free((*freq)[l][m]);
                        }
                        free((*freq)[l]);
                    }
                    free(*freq);
                    return 1;
                }
            }
        }
    }
    return 0;
}

void free_freq(uint64_t max_c1, uint64_t max_c2, uint64_t max_c3, uint32_t *****freq) {
    if (!freq || !*freq) return;

    for (int i = 0; i < max_c1; i++) {
        if (!(*freq)[i]) continue;

        for (int j = 0; j < max_c2; j++) {
            if (!(*freq)[i][j]) continue;

            for (int k = 0; k < max_c3; k++) {
                free((*freq)[i][j][k]);
            }
            free((*freq)[i][j]);
        }
        free((*freq)[i]);
    }
    free(*freq);
    *freq = NULL;
}

int minDistance(double dist[], int visited[], int size) {
    double min = DBL_MAX;
    int min_index = -1;

    for (int v = 0; v < size; v++) {
        if (!visited[v] && dist[v] <= min) {
            min = dist[v];
            min_index = v;
        }
    }

    return min_index;
}

void dijkstra(double **graph, int nodes, int bitdepth, char **seq) {
    double dist[nodes];
    int visited[nodes];
    int prev[nodes];

    int i;
    for (i = 0; i < nodes; i++) {
        dist[i] = DBL_MAX;
        visited[i] = 0;
        prev[i] = -1;
    }

    dist[0] = 0;

    for (i = 0; i < nodes - 1; i++) {
        int u = minDistance(dist, visited, nodes);
        if (u == -1) break;
        visited[u] = 1;

        int v;
        for (v = 0; v < nodes; v++) {
            if (!visited[v] && graph[u][v] != NO_EDGE &&
                dist[u] != DBL_MAX &&
                dist[u] + graph[u][v] < dist[v]) {
                dist[v] = dist[u] + graph[u][v];
                prev[v] = u;
            }
        }
    }

    *seq = malloc(100);
    int p = 0;
    int prev_bp = prev[nodes-1];
    int first = 1;

    int *values = malloc(nodes * sizeof(int));
    int value_count = 0;

    while (prev_bp != 0) {
        int len = bitdepth;
        int next = bitdepth;
        int value = prev_bp - 1;

        while (value >= next) {
            next += len - 1;
            len--;
        }
        values[value_count++] = len - (next - value - 1);

        prev_bp = prev[prev_bp];
    }

    for (int i = value_count - 1; i >= 0; i--) {
        if (!first) {
            p += snprintf(*seq + p, 100 - p, ",%d", values[i]);
        } else {
            p += snprintf(*seq + p, 100 - p, "%d", values[i]);
            first = 0;
        }
    }
}

void compute_dijkstra(double ***weights, int bitdepth, char **seq) {
    int max_groups = bitdepth;
    int count = 2 + bitdepth * (bitdepth + 1) / 2;
    
    int** nodes = malloc(count * sizeof(int*));
    for (int i = 0; i < count; i++) {
        nodes[i] = malloc(2 * sizeof(int));
    }

    double **dijkstra_matrix = malloc(count * sizeof(double*));
    for (int i = 0; i < count; i++) {
        dijkstra_matrix[i] = malloc(count * sizeof(double));
        
        for (int j = 0; j < count; j++) {
            dijkstra_matrix[i][j] = NO_EDGE;
        }
    }

    int idx = 0;

    nodes[idx][0] = -1;
    nodes[idx][1] = 1;
    idx++;

    for (int i = 0; i < bitdepth; i++) {
        for (int j = 1; j <= max_groups; j++) {
            if ((i + j - 1) < bitdepth) {
                nodes[idx][0] = i;
                nodes[idx][1] = j;
                idx++;
            }
        }
    }

    nodes[idx][0] = bitdepth;
    nodes[idx][1] = bitdepth;   

    for(int i = 0; i < count; i++) {
        for(int j = 0; j < count; j++) {
            if (nodes[i][0] + nodes[i][1] == nodes[j][0]) {
                if (nodes[j][0] != 8) {
                    dijkstra_matrix[i][j] = (*weights)[nodes[j][1] -1][nodes[j][0]];
                } else {
                    dijkstra_matrix[i][j] = 0;
                }
            }
        }
    }

    dijkstra(dijkstra_matrix, count, bitdepth, seq);

    for (int i = 0; i < count; i++) {
        free(nodes[i]);
    }
    free(nodes);
}

int main(int argc, char *argv[]) {
    if (argc != 5) {
        fprintf(stderr, "Usage: %s <divisions> <search> <context> <measure>\n", argv[0]);
        return -1;
    }

    char *divisions_str = argv[1];

    int divisions[16];

    int num_groups = 0;
    int search = atoi(argv[2]);
    int context = atoi(argv[3]);
    double measure = atof(argv[4]);

    Header header;
    if (header_parse_stdin(&header) != 0) {
        return 1;
    }

    print_header(&header);

    DataPacket imageData = {0}; 
    if (header.state == COMPRESS) {
        while(body_parse_stdin(&imageData) == 0) {
            if ((imageData.type != DATA_TYPE_IMAGE) && (imageData.type != DATA_TYPE_RESIDUALS)) {
                continue; // Implement a forward data
            }

            uint64_t ***inputData = NULL;

            if (get_image_from_stdin(&imageData, header, &inputData) != 0) {
                fprintf(stderr, "Error generating image\n");
                return 1;
            }

            if (search) {
                uint64_t max_c1, max_c2, max_c3;
                uint64_t symbol = (1 << header.bits);
                uint32_t ****Qfreq;
                uint32_t ****Pointfreq;
                get_max_context(symbol, context, &max_c1, &max_c2, &max_c3);
                initialize_freq(max_c1, max_c2, max_c3, symbol, &Qfreq);
                initialize_freq(max_c1, max_c2, max_c3, symbol, &Pointfreq);
                
                for (int c1 = 0; c1 < max_c1; c1++) {
                for (int c2 = 0; c2 < max_c2; c2++) {
                for (int c3 = 0; c3 < max_c3; c3++) {
                    for (int i = 0; i <= symbol; i++) {
                        Qfreq[c1][c2][c3][i] = 0;
                    }
                } 
                }
                }

                uint64_t c1, c2, c3;

                for (uint64_t z = 0; z < header.z; z++) {
                for (uint64_t y = 0; y < header.y; y++) {
                for (uint64_t x = 0; x < header.x; x++) {
                    get_context(context, symbol, inputData, z, y, x, header.x -1, &c1, &c2, &c3);
                    if ((z * header.y * header.x + y * header.x + x) == (int)(header.z * header.y * header.x * measure)) {
                        for (int i = 0; i < max_c1; i++) {
                        for (int j = 0; j < max_c2; j++) {
                        for (int k = 0; k < max_c3; k++) {
                            memcpy(Pointfreq[i][j][k], Qfreq[i][j][k], sizeof(uint32_t) * (symbol+1));
                        }
                        }
                        }
                    }
                    Qfreq[c1][c2][c3][inputData[z][y][x]] += 1;
                    Qfreq[c1][c2][c3][symbol] += 1;
                }
                }
                }

                double **WMatrix = (double **)malloc(header.bits * sizeof(double *));
                for (int i = 0; i < header.bits; i++) {
                    WMatrix[i] = (double *)malloc(header.bits * sizeof(double));
                }
                
                uint32_t ****QMfreq;
                uint32_t ****PointMfreq;
                initialize_freq(max_c1, max_c2, max_c3, symbol, &QMfreq);
                initialize_freq(max_c1, max_c2, max_c3, symbol, &PointMfreq);
                
                // Compute Dijkstra matrix
                for(int My = 0; My < header.bits; My++) {
                    for (int Mx = 0; Mx < header.bits - My; Mx++) {

                        int shift = My;
                        int max_words = 1 << (Mx + 1);
                        int Nbp = max_words - 1;
                        
                        for (uint64_t i = 0; i < max_c1; i++) {
                        for (uint64_t j = 0; j < max_c2; j++) {
                        for (uint64_t k = 0; k < max_c3; k++) {
                        for (uint64_t v = 0; v <= symbol; v++) {
                            QMfreq[i][j][k][v] = 0;
                            PointMfreq[i][j][k][v] = 0;
                        }
                        }
                        }
                        }

                        for (uint64_t i = 0; i < max_c1; i++) {
                        for (uint64_t j = 0; j < max_c2; j++) {
                        for (uint64_t k = 0; k < max_c3; k++) {
                        for (uint64_t v = 0; v < symbol; v++) {
                            QMfreq[(i >> shift) & Nbp][(j >> shift) & Nbp][(k >> shift) & Nbp][(v >> shift) & Nbp] += Qfreq[i][j][k][v];
                            PointMfreq[(i >> shift) & Nbp][(j >> shift) & Nbp][(k >> shift) & Nbp][(v >> shift) & Nbp] += Pointfreq[i][j][k][v];
                        }
                        }
                        }
                        }

                        for (uint64_t i = 0; i < max_c1; i++) {
                        for (uint64_t j = 0; j < max_c2; j++) {
                        for (uint64_t k = 0; k < max_c3; k++) {
                            QMfreq[(i >> shift) & Nbp][(j >> shift) & Nbp][(k >> shift) & Nbp][symbol] += Qfreq[i][j][k][symbol];
                            PointMfreq[(i >> shift) & Nbp][(j >> shift) & Nbp][(k >> shift) & Nbp][symbol] += Pointfreq[i][j][k][symbol];
                        }
                        }
                        }

                        uint64_t max_Mc1 = max_words < max_c1 ? max_words : max_c1;
                        uint64_t max_Mc2 = max_words < max_c2 ? max_words : max_c2;
                        uint64_t max_Mc3 = max_words < max_c3 ? max_words : max_c3;

                        double Hqix_point = 0;
                        double Hqix_end = 0;
                        for (uint64_t i = 0; i < max_Mc1; i++) {
                        for (uint64_t j = 0; j < max_Mc2; j++) {
                        for (uint64_t k = 0; k < max_Mc3; k++) {
                            if ((double)QMfreq[i][j][k][symbol] != 0) {
                                double Hqixc_point = 0;
                                double Hqixc_end = 0;
                                for (uint64_t v = 0; v < max_words; v++) {
                                    double Pxy = (double)(QMfreq[i][j][k][v]) / QMfreq[i][j][k][symbol];
                                    double Qxy_point = ((double)(PointMfreq[i][j][k][v]) + 1) / (PointMfreq[i][j][k][symbol] + max_words);
                                    double Qxy_end = ((double)(QMfreq[i][j][k][v]) + 1) / (QMfreq[i][j][k][symbol] + max_words);
        
                                    Hqixc_point -= Pxy * log2(Qxy_point);
                                    Hqixc_end -= Pxy * log2(Qxy_end);
                                }
                                Hqix_point += Hqixc_point * ((double)QMfreq[i][j][k][symbol] / (header.z * header.y * header.x));
                                Hqix_end += Hqixc_end * ((double)QMfreq[i][j][k][symbol] / (header.z * header.y * header.x));
                            }
                        }
                        }
                        }
        
                        double mp = measure;
                        double x = (Mx + 1);
                        double y = Hqix_end;
                        double z = Hqix_point;
        
                        double b = (double)((-x + mp * x - mp * y + z) * (-x + mp * x - mp * y + z)) / ((-1 + mp) * mp * (x - y) * (x - z) * (y - z));
                        double c = -(double)(mp *(y - z)) / (x - mp * x + mp * y - z);
                        double d = (double)(- x * y + mp * x * z + y * z - mp * y * z) / (- x + mp * x - mp * y + z);
        
                        
                        if (c > 0) {
                            WMatrix[Mx][My] = d + (log((c+1)/c)) / b;
                        }
                        else {
                            WMatrix[Mx][My] = Hqix_end;
                        }
                    }
                }

                for(int i = 0; i < header.bits; i++) {
                    for (int j = 0; j < header.bits; j++) {
                        fprintf(stderr, "%.2f, ", fabs(WMatrix[j][i]));
                    }
                    fprintf(stderr, "\n");
                }

                char *seq;
                compute_dijkstra(&WMatrix, header.bits, &seq);

                char *token = strtok(seq, ",");
                while (token != NULL && num_groups < 16) {
                    divisions[num_groups++] = atoi(token);
                    token = strtok(NULL, ",");
                }

                free_freq(max_c1, max_c2, max_c3, &Pointfreq);
                free_freq(max_c1, max_c2, max_c3, &Qfreq);
            } else {

                char *token = strtok(divisions_str, ",");
                while (token != NULL && num_groups < 16) {
                    divisions[num_groups++] = atoi(token);
                    token = strtok(NULL, ",");
                }
            }

            uint8_t position = header.bits;
            for (uint8_t group = 0; group < num_groups; group++) {
                // Por cada nuevo grupo de bitplane
                DataPacket outputData = {}; 
                outputData.id = 0;
                outputData.type = DATA_TYPE_IMAGE;
                outputData.bits = (uint8_t)divisions[group];
                outputData.endian = 'l';
                start_body(&outputData, stdout);

                uint8_t shift = (position - divisions[group]);
                uint16_t data_and = ((1 << divisions[group]) - 1);

                void *row_buffer;
                size_t element_size;

                if (divisions[group] <= 8) {
                    row_buffer = (uint8_t *)calloc(header.x * header.y * header.z, sizeof(uint8_t));
                    element_size = sizeof(uint8_t);
                } else {
                    row_buffer = (uint16_t *)calloc(header.x * header.y * header.z, sizeof(uint16_t));
                    element_size = sizeof(uint16_t);
                }
                

                for (size_t z = 0; z < header.z; z++) {
                    for (size_t y = 0; y < header.y; y++) {
                        for (size_t x = 0; x < header.x; x++) {
                            size_t index = (z * header.y + y) * header.x + x;
                            uint16_t value = (inputData[z][y][x] >> shift) & data_and;

                            if (divisions[group] <= 8) {
                                ((uint8_t *)row_buffer)[index] = (uint8_t)value;
                            } else {
                                ((uint16_t *)row_buffer)[index] = value;
                            }
                        }
                    }
                }

                fwrite(row_buffer, element_size, header.x * header.y * header.z, stdout);
                free(row_buffer);
                
                position -= divisions[group];
                end_body(&outputData, stdout);

            }
            free_image(inputData, header);
        }

    }
    else {
        uint64_t ***outputData = NULL;
        initialize_image_matrix(header.z, header.y, header.x, &outputData);
        uint8_t position = header.bits;
        uint8_t group = 0;

        while(body_parse_stdin(&imageData) == 0) {
            if ((imageData.type != DATA_TYPE_IMAGE) && (imageData.type != DATA_TYPE_RESIDUALS)) {
                continue; // Implement a forward data
            }

            uint64_t ***inputData = NULL;
            if (get_image_from_stdin(&imageData, header, &inputData) != 0) {
                fprintf(stderr, "Error generating image\n");
                return 1;
            }

            uint8_t shift = (position - imageData.bits);
            for (size_t z = 0; z < header.z; z++) {
                for (size_t y = 0; y < header.y; y++) {
                    for (size_t x = 0; x < header.x; x++) {
                        outputData[z][y][x] |= (inputData[z][y][x] << shift);
                    }
                }
            }
            free_image(inputData, header);
            position -= imageData.bits;
            group++;
        }

        DataPacket outputBody = {0}; 
        outputBody.id = 0;
        outputBody.type = DATA_TYPE_IMAGE;
        outputBody.bits = header.bits;
        outputBody.endian = 'l';
        start_body(&outputBody, stdout);
        

        for (size_t z = 0; z < header.z; z++) {
            for (size_t y = 0; y < header.y; y++) {
                for (size_t x = 0; x < header.x; x++) {
                    fwrite(&outputData[z][y][x], (header.bits <= 8) ? sizeof(uint8_t) : sizeof(uint16_t), 1, stdout);
                }
            }
        }
        end_body(&outputBody, stdout);
        free_image(outputData, header);
    }

    return 0;
}

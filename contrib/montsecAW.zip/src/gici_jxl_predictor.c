#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "utils/header.h"
#include "utils/body.h"
#include "utils/image_converter.h"

#define BUFFER_SIZE 1024

#define KNUM_PREDICTORS 4
#define KPRED_EXTRA_BITS 3
#define KPREDICTION_ROUND ((1 << KPRED_EXTRA_BITS) >> 1) - 1

uint32_t PWeights[KNUM_PREDICTORS];
int32_t PredVal;
int w[4] = {0xd, 0xc, 0xc, 0xb};
int32_t p[4];

const uint32_t divlookup[64] = {
    16777216, 8388608, 5592405, 4194304, 3355443, 2796202, 2396745, 2097152,
    1864135,  1677721, 1525201, 1398101, 1290555, 1198372, 1118481, 1048576,
    986895,   932067,  883011,  838860,  798915,  762600,  729444,  699050,
    671088,   645277,  621378,  599186,  578524,  559240,  541200,  524288,
    508400,   493447,  479349,  466033,  453438,  441505,  430185,  419430,
    409200,   399457,  390167,  381300,  372827,  364722,  356962,  349525,
    342392,   335544,  328965,  322638,  316551,  310689,  305040,  299593,
    294337,   289262,  284359,  279620,  275036,  270600,  266305,  262144};


int initialize_error_matrix(int num_pred, int x, uint32_t ***matrix) {
    *matrix = (uint32_t **)malloc(num_pred * sizeof(uint32_t *));
    if (!*matrix) return 1;

    for (int i = 0; i < num_pred; i++) {
        (*matrix)[i] = (uint32_t *)calloc((x + 2) * 2, sizeof(uint32_t));
        if (!(*matrix)[i]) {
            for (int k = 0; k < i; k++) {
                free((*matrix)[k]);
            }
            free(*matrix);
            return 1;
        }
    }
    return 0;
}

uint16_t map_difference(int residual, int prediction, int min, int max) {
    int32_t theta = (prediction - min < max - prediction) ? (prediction - min) : (max - prediction);
    uint16_t mappedDiff = 0;
    if (residual >= 0 && residual <= theta) {
        mappedDiff = residual << 1;
    } else if (residual >= -theta && residual < 0) {
        mappedDiff = (abs(residual) << 1) - 1;

    } else {
        mappedDiff = theta + abs(residual);
    }

    return mappedDiff;
}

int unmap_difference(uint16_t mapped_difference, int prediction, int min, int max) {
    uint32_t left_interval = (prediction - min <= max - prediction);
    int32_t theta = left_interval ? (prediction - min) : (max - prediction);
    int prediction_error;

    if (mapped_difference <= (theta << 1)) {
        if ((mapped_difference & 1) == 0) {
            prediction_error = mapped_difference >> 1;
        } else {
            prediction_error = -((mapped_difference + 1) >> 1);
        }
    } else {
        if (left_interval) {
            prediction_error = mapped_difference - theta;
        } else {
            prediction_error = theta - mapped_difference;
        }
    }

    return prediction_error;
}

double sign(double x) {
    return (x > 0) - (x < 0);
}

uint32_t VMax(uint32_t a, uint32_t b) {
    return (a > b) ? a : b;
}

uint32_t VMin(uint32_t a, uint32_t b) {
    return (a < b) ? a : b;
}

uint64_t add_bits(uint64_t x) {
    return x << KPRED_EXTRA_BITS;
}


uint32_t ErrorWeight(uint64_t x, uint32_t maxweight) {
    int shift = 31 - __builtin_clz(x + 1) - 5;
    if (shift < 0) shift = 0;
    return 4 + ((maxweight * divlookup[x >> shift]) >> shift);
}

int32_t WeightedAverage(int32_t *p) {
    uint32_t weight_sum = 0;
    for (size_t i = 0; i < KNUM_PREDICTORS; i++) {
        weight_sum += PWeights[i];
    }

    uint32_t log_weight = 31 - __builtin_clz(weight_sum);
    weight_sum = 0;
    for (size_t i = 0; i < KNUM_PREDICTORS; i++) {
        PWeights[i] >>= log_weight - 4;
        weight_sum += PWeights[i];
    }

    int32_t sum = (weight_sum >> 1) - 1;
    for (size_t i = 0; i < KNUM_PREDICTORS; i++) {
      sum += p[i] * PWeights[i];
    }

    return (uint32_t)(((uint64_t)sum * divlookup[weight_sum - 1]) >> 24);
}

void update(uint64_t ***inputData, uint32_t ***predErrors, int32_t **error, int columns, int z, int y, int x) {
    size_t cur_row = y & 1 ? 0 : (columns + 2);
    size_t prev_row = y & 1 ? (columns + 2) : 0;
    int32_t val = add_bits(inputData[z][y][x]);

    (*error)[cur_row + x] = PredVal - val;
    for (size_t i = 0; i < KNUM_PREDICTORS; i++) {
      int32_t err = (abs(p[i] - val) + KPREDICTION_ROUND) >> KPRED_EXTRA_BITS;
      (*predErrors)[i][cur_row + x] = err;
      (*predErrors)[i][prev_row + x + 1] += err;
    }
}

int predict(uint64_t ***inputData, uint32_t ***predErrors, int32_t **error, double *n_pred, int min, int max, int depth, int rows, int columns, int z, int y, int x) {

    int p1C = 8;
    int p2C = 8;
    int p3Ca = 4;
    int p3Cb = 0;
    int p3Cc = 3;
    int p3Cd = 23;
    int p3Ce = 2;

    int64_t W = x != 0 ? inputData[z][y][x-1] : y != 0 ? inputData[z][y-1][x] : 0;
    int64_t N = y != 0 ? inputData[z][y-1][x] : W;
    int64_t NW = (x != 0 && y != 0) ? inputData[z][y-1][x-1] : W;
    int64_t NE = (x + 1 < columns && y != 0) ? inputData[z][y-1][x+1] : N;
    int64_t NN = (y > 1) ? inputData[z][y-2][x] : N;

    size_t cur_row = y & 1 ? 0 : (columns + 2);
    size_t prev_row = y & 1 ? (columns + 2) : 0;
    size_t pos_N = prev_row + x;
    size_t pos_NE = x < columns - 1 ? pos_N + 1 : pos_N;
    size_t pos_NW = x > 0 ? pos_N - 1 : pos_N;

    for (size_t i = 0; i < KNUM_PREDICTORS; i++) {
        PWeights[i] = (*predErrors)[i][pos_N] + (*predErrors)[i][pos_NE] + (*predErrors)[i][pos_NW];
        PWeights[i] = ErrorWeight(PWeights[i], w[i]);
    }

    N = add_bits(N);
    W = add_bits(W);
    NE = add_bits(NE);
    NW = add_bits(NW);
    NN = add_bits(NN);


    int32_t teW = x == 0 ? 0 : (*error)[cur_row + x - 1];
    int32_t teN = (*error)[pos_N];
    int32_t teNW = (*error)[pos_NW];
    int32_t sumWN = teW + teN;
    int32_t teNE = (*error)[pos_NE];


    p[0] = W + NE - N;
    p[1] = N - (((sumWN + teNE) * p1C) >> 5);
    p[2] = W - (((sumWN + teNW) * p2C) >> 5);
    p[3] = N - ((teNW * p3Ca + teN * p3Cb + teNE * p3Cc + (NN - N) * p3Cd + (NW - W) * p3Ce) >> 5);

    PredVal = WeightedAverage(p);
    
    if (!(((teN ^ teW) | (teN ^ teNW)) > 0)) {
        int32_t mx = VMax(W, VMax(NE, N));
        int32_t mn = VMin(W, VMin(NE, N));

        PredVal = VMax(mn, VMin(mx, PredVal));
    }

    return (int)((PredVal + KPREDICTION_ROUND) >> KPRED_EXTRA_BITS);
}



int main(int argc, char *argv[]) {
    if (argc != 7) {
        fprintf(stderr, "Usage: %s\n <LR> <L1> <L2> <alpha> <gamma> <batch>", argv[0]);
        return 1;
    }


    Header header;
    if (header_parse_stdin(&header) != 0) {
        return 1;
    }

    DataPacket imageData = {0}; 

    while(body_parse_stdin(&imageData) == 0) {
        if ((imageData.type != DATA_TYPE_IMAGE) && (imageData.type != DATA_TYPE_RESIDUALS)) {
            continue; // Implement a forward data
        }

        uint64_t ***inputData = NULL;

        if (get_image_from_stdin(&imageData, header, &inputData) != 0) {
            fprintf(stderr, "Error generating image\n");
            return 1;
        }

        if (header.state == COMPRESS) {
            header.data = RESIDUAL;
        }
        else {
            header.data = RAW;
        }

        print_header(&header);


        DataPacket outputData = {0}; 
        outputData.id = 0;
        outputData.bits = header.bits;
        outputData.endian = 'l';

        if (header.state == COMPRESS) {
            outputData.type = DATA_TYPE_RESIDUALS;

            start_body(&outputData, stdout);

            void* row_buffer;
            size_t pixel_size = (header.bits == 8) ? sizeof(uint8_t) : sizeof(uint16_t);
            size_t buffer_size = header.x * header.y * header.z * pixel_size;
            row_buffer = malloc(buffer_size);

            size_t min = 0;
            size_t max = (1 << header.bits) - 1;
            
            double n_pred;
            uint32_t** predErrorMatrix;
            int32_t* errorMatrix = (int32_t *)calloc((header.x + 2) * 2, sizeof(int32_t));

            initialize_error_matrix(KNUM_PREDICTORS, header.x, &predErrorMatrix);

            for (size_t z = 0; z < header.z; z++) {
                for (size_t y = 0; y < header.y; y++) {
                    for (size_t x = 0; x < header.x; x++) {
                        uint16_t prediction = predict(inputData, &predErrorMatrix, &errorMatrix, &n_pred, min, max, header.z, header.y, header.x, z, y, x); 
                        update(inputData, &predErrorMatrix, &errorMatrix, header.x, z, y, x);
                        //fprintf(stderr, "%d %d  pred -> %d     real -> %d   diff -> %i \n", x, y, prediction, inputData[z][y][x], (int32_t)(inputData[z][y][x] - prediction));
                        uint16_t mapped_residual = map_difference((int32_t)(inputData[z][y][x] - prediction), prediction, min, max);

                        if (header.bits == 8) {
                            ((uint8_t*)row_buffer)[(z * header.y + y) * header.x + x] = (uint8_t)mapped_residual;
                        } else {
                            ((uint16_t*)row_buffer)[(z * header.y + y) * header.x + x] = mapped_residual;
                        }
                    }
                }
            }
            
            fwrite(row_buffer, pixel_size, header.x * header.y * header.z, stdout);
            free(row_buffer);
            end_body(&outputData, stdout);
        }
        else {
            outputData.type = DATA_TYPE_IMAGE;

            start_body(&outputData, stdout);

            void* row_buffer;
            size_t pixel_size = (header.bits == 8) ? sizeof(uint8_t) : sizeof(uint16_t);
            size_t buffer_size = header.x * header.y * header.z * pixel_size;
            row_buffer = malloc(buffer_size);

            size_t min = 0;
            size_t max = (1 << header.bits) - 1;
            
            double n_pred;
            uint32_t** predErrorMatrix;
            int32_t* errorMatrix = (int32_t *)calloc((header.x + 2) * 2, sizeof(int32_t));

            initialize_error_matrix(KNUM_PREDICTORS, header.x, &predErrorMatrix);

            for (size_t z = 0; z < header.z; z++) {
                for (size_t y = 0; y < header.y; y++) {
                    for (size_t x = 0; x < header.x; x++) {
                        uint16_t prediction = predict(inputData, &predErrorMatrix, &errorMatrix, &n_pred, min, max, header.z, header.y, header.x, z, y, x);
                        uint16_t result = unmap_difference(inputData[z][y][x], prediction, min, max) + prediction;
                        inputData[z][y][x] = result;
                        update(inputData, &predErrorMatrix, &errorMatrix, header.x, z, y, x);
                        
                        if (header.bits == 8) {
                            ((uint8_t*)row_buffer)[(z * header.y + y) * header.x + x] = (uint8_t)result;
                        } else {
                            ((uint16_t*)row_buffer)[(z * header.y + y) * header.x + x] = result;
                        }
                    }
                }
            }

            fwrite(row_buffer, pixel_size, header.x * header.y * header.z, stdout);
            free(row_buffer);
            end_body(&outputData, stdout);
        }

        free_image(inputData, header);

    }

    return 0;
}

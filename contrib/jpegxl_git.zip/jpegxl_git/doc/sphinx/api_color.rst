Color encoding and conversion
=============================

.. doxygengroup:: libjxl_color
   :members:
   :private-members:

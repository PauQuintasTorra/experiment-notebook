This directory contains modified configuration files from the reference HEVC
encoder, the source code of which can be found at: https://hevc.hhi.fraunhofer.de/svn/svn_HEVCSoftware/

## JPEG XL "extras"

The files in this directory do not form part of the library or codec and are
only used by tests or specific internal tools that have access to the internals
of the library.
